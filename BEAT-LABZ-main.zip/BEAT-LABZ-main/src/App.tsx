import React, { useCallback, useEffect, useRef, useState } from 'react';
import { onAuthStateChanged, type User } from 'firebase/auth';
import {
  Sliders,
  Sparkles,
  Radio,
  Share2,
  MapPin,
  Bot,
  Cloud,
  Users,
  GraduationCap,
  Play,
  Square,
  Save,
  Menu,
  X,
  VolumeX,
} from 'lucide-react';
import { auth } from './firebase';
import { audioEngine } from './audio/audioEngine';
import {
  INITIAL_COLLABORATORS,
  INITIAL_STUDIO_PROJECT,
  MASTERING_PRESETS,
  type ProjectTemplateSpec,
} from './data/defaultStudio';
import type {
  CollaboratorProfile,
  RecordedTake,
  StudioProject,
  WorkspaceTab,
} from './types/studio';
import { ErrorBoundary } from './components/ErrorBoundary';
import { StudioDawView } from './components/StudioDawView';
import { MasteringLabView } from './components/MasteringLabView';
import { LivePerformanceView } from './components/LivePerformanceView';
import { ConnectView } from './components/ConnectView';
import { LocationShareView } from './components/LocationShareView';
import { AiAssistantView } from './components/AiAssistantView';
import { CloudStudioView } from './components/CloudStudioView';
import { CollaborationStudioView } from './components/CollaborationStudioView';
import { MusicEducationView } from './components/MusicEducationView';
import { SharedLinkViewer } from './components/SharedLinkViewer';

const PROJECTS_STORAGE_KEY = 'beatlabz_projects_v1';

const NAV_ITEMS: Array<{ id: WorkspaceTab; label: string; shortLabel: string; icon: React.ComponentType<{ className?: string }> }> = [
  { id: 'studio', label: 'Studio DAW', shortLabel: 'Studio', icon: Sliders },
  { id: 'mastering', label: 'Mastering Lab', shortLabel: 'Master', icon: Sparkles },
  { id: 'live', label: 'Live Stage', shortLabel: 'Stage', icon: Radio },
  { id: 'collaborate', label: 'Collab Studio', shortLabel: 'Collab', icon: Users },
  { id: 'connect', label: 'Beat Labz Connect', shortLabel: 'Connect', icon: Share2 },
  { id: 'location', label: 'Location Share', shortLabel: 'Location', icon: MapPin },
  { id: 'ai', label: 'AI Assistant', shortLabel: 'AI Coach', icon: Bot },
  { id: 'cloud', label: 'Cloud Studio', shortLabel: 'Cloud', icon: Cloud },
  { id: 'learn', label: 'Music Education', shortLabel: 'Learn', icon: GraduationCap },
];

export default function App() {
  const urlParams = new URLSearchParams(window.location.search);
  const shareParam = urlParams.get('share');
  const locParam = urlParams.get('loc');
  const [viewingShare, setViewingShare] = useState(Boolean(shareParam || locParam));

  const [activeTab, setActiveTab] = useState<WorkspaceTab>('studio');
  const [mobileDrawerOpen, setMobileDrawerOpen] = useState(false);

  // Projects state (persisted locally + synced to Cloud Studio when signed in)
  const [savedProjects, setSavedProjects] = useState<StudioProject[]>(() => {
    try {
      const raw = localStorage.getItem(PROJECTS_STORAGE_KEY);
      if (raw) {
        const parsed = JSON.parse(raw) as StudioProject[];
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // ignore
    }
    return [INITIAL_STUDIO_PROJECT];
  });
  const [activeProjectId, setActiveProjectId] = useState<string>(() => savedProjects[0]?.id ?? INITIAL_STUDIO_PROJECT.id);
  const project = savedProjects.find((p) => p.id === activeProjectId) ?? savedProjects[0] ?? INITIAL_STUDIO_PROJECT;

  const [isPlaying, setIsPlaying] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);
  const [metronomeOn, setMetronomeOn] = useState(false);
  const [emergencyMuted, setEmergencyMuted] = useState(false);
  const [saveToast, setSaveToast] = useState<string | null>(null);

  const [recordings, setRecordings] = useState<RecordedTake[]>([]);
  const [exportedMixes, setExportedMixes] = useState<
    Array<{ id: string; name: string; format: 'WAV' | 'MP3'; sizeBytes: number; objectUrl?: string; blobUrl: string }>
  >([]);
  const [collaborators, setCollaborators] = useState<CollaboratorProfile[]>(INITIAL_COLLABORATORS);
  const [collabRoomId, setCollabRoomId] = useState('studio-main');

  // Firebase Auth state
  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);

  // Google Maps API key & Case A Demo Quota warning
  const [mapsApiKey, setMapsApiKey] = useState<string>(import.meta.env.VITE_GOOGLE_MAPS_API_KEY || '');
  const [gmpQuotaExceeded, setGmpQuotaExceeded] = useState(false);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (u) => {
      setUser(u);
      setAuthReady(true);
    });
    return () => unsub();
  }, []);

  useEffect(() => {
    const onQuota = () => setGmpQuotaExceeded(true);
    window.addEventListener('gmp-quota-exceeded', onQuota);
    return () => window.removeEventListener('gmp-quota-exceeded', onQuota);
  }, []);

  useEffect(() => {
    fetch('/api/config/public')
      .then((r) => r.json())
      .then((data) => {
        if (data?.mapsApiKey && !mapsApiKey) {
          setMapsApiKey(data.mapsApiKey);
        }
      })
      .catch(() => {
        // ignore if offline
      });
  }, [mapsApiKey]);

  const [undoCount, setUndoCount] = useState(0);
  const undoStackRef = useRef<StudioProject[]>([]);

  const updateProject = useCallback(
    (updater: (prev: StudioProject) => StudioProject) => {
      setSavedProjects((prevList) =>
        prevList.map((p) => {
          if (p.id !== project.id) return p;
          undoStackRef.current = [structuredClone(p), ...undoStackRef.current].slice(0, 20);
          setUndoCount(undoStackRef.current.length);
          return { ...updater(p), updatedAt: new Date().toISOString() };
        })
      );
    },
    [project.id]
  );

  const undoLastEdit = useCallback(() => {
    const [previous, ...rest] = undoStackRef.current;
    if (!previous) return;
    undoStackRef.current = rest;
    setUndoCount(rest.length);
    setSavedProjects((prevList) => prevList.map((p) => (p.id === previous.id ? previous : p)));
  }, []);

  const persistProjectsLocally = () => {
    localStorage.setItem(PROJECTS_STORAGE_KEY, JSON.stringify(savedProjects));
    setSaveToast('Project saved locally');
    setTimeout(() => setSaveToast(null), 2000);
  };

  useEffect(() => {
    localStorage.setItem(PROJECTS_STORAGE_KEY, JSON.stringify(savedProjects));
  }, [savedProjects]);

  // Real-time step sequencer clock driving Web Audio Engine (with authentic Swing %)
  const projectRef = useRef(project);
  projectRef.current = project;
  const metronomeRef = useRef(metronomeOn);
  metronomeRef.current = metronomeOn;
  const stepRef = useRef(0);

  useEffect(() => {
    if (!isPlaying) return;
    audioEngine.ensureContext();
    const stepMs = (60 / Math.max(30, Math.min(300, project.bpm)) / 4) * 1000;
    const pendingTimers: number[] = [];

    const fireStep = (s: number) => {
      setCurrentStep(s);
      const curProj = projectRef.current;
      const hasSolo = curProj.tracks.some((t) => t.solo);

      if (metronomeRef.current && s % 4 === 0) {
        audioEngine.triggerMetronome(s === 0);
      }

      curProj.tracks.forEach((trk) => {
        const audible = hasSolo ? trk.solo : !trk.muted;
        if (!audible || !trk.steps[s]) return;
        if (trk.kind === 'drums') {
          audioEngine.triggerDrumVoice(trk.notes[s] ?? 0, trk.volume, trk.pan);
        } else {
          audioEngine.triggerNote(trk.notes[s] ?? 60, {
            preset: trk.instrumentPreset,
            volume: trk.volume,
            pan: trk.pan,
            durationSec: (stepMs / 1000) * 1.7,
            reverbSend: trk.reverbSend,
            eqLow: trk.eqLow,
            eqHigh: trk.eqHigh,
          });
        }
      });
    };

    const scheduleStep = () => {
      const s = stepRef.current;
      const swingPct = projectRef.current.swing ?? 0;
      const swingDelayMs = s % 2 === 1 ? ((Math.max(0, Math.min(60, swingPct)) / 100) * stepMs) * 0.5 : 0;

      if (swingDelayMs > 2) {
        const tId = window.setTimeout(() => fireStep(s), swingDelayMs);
        pendingTimers.push(tId);
      } else {
        fireStep(s);
      }

      stepRef.current = (s + 1) % 16;
    };

    scheduleStep();
    const intervalId = setInterval(scheduleStep, stepMs);
    return () => {
      clearInterval(intervalId);
      pendingTimers.forEach((tId) => clearTimeout(tId));
    };
  }, [isPlaying, project.bpm]);

  const togglePlay = useCallback(() => {
    audioEngine.ensureContext();
    if (isPlaying) {
      setIsPlaying(false);
      stepRef.current = 0;
      setCurrentStep(0);
    } else {
      stepRef.current = 0;
      setIsPlaying(true);
    }
  }, [isPlaying]);

  useEffect(() => {
    const onKeyDown = (e: KeyboardEvent) => {
      const tag = (e.target as HTMLElement | null)?.tagName;
      const isEditing = tag === 'INPUT' || tag === 'TEXTAREA' || tag === 'SELECT';
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'z' && !isEditing) {
        e.preventDefault();
        undoLastEdit();
        return;
      }
      if (e.code === 'Space' && !isEditing) {
        e.preventDefault();
        togglePlay();
      }
    };
    window.addEventListener('keydown', onKeyDown);
    return () => window.removeEventListener('keydown', onKeyDown);
  }, [togglePlay, undoLastEdit]);

  const toggleEmergencyMute = () => {
    const next = !emergencyMuted;
    setEmergencyMuted(next);
    audioEngine.setEmergencyMute(next);
  };

  const createNewProject = (template?: ProjectTemplateSpec) => {
    const newId = `proj_${Date.now()}`;
    const baseTracks = structuredClone(INITIAL_STUDIO_PROJECT.tracks);
    if (template) {
      baseTracks[0].steps = [...template.kickSteps];
      baseTracks[1].steps = [...template.hatSteps];
      baseTracks[2].notes = [...template.bassNotes];
      baseTracks[3].notes = [...template.padNotes];
    }
    const newProj: StudioProject = {
      ...INITIAL_STUDIO_PROJECT,
      id: newId,
      title: template ? template.name : `Studio Session ${savedProjects.length + 1}`,
      bpm: template ? template.bpm : INITIAL_STUDIO_PROJECT.bpm,
      swing: template ? template.swing : 0,
      musicalKey: template ? template.musicalKey : INITIAL_STUDIO_PROJECT.musicalKey,
      timeSignature: template ? template.timeSignature : INITIAL_STUDIO_PROJECT.timeSignature,
      tracks: baseTracks,
      chordChart: template
        ? [
            {
              id: `cc_${Date.now()}`,
              section: 'Main Groove',
              chords: [...template.chords],
              lyrics: `${template.genre} arrangement groove`,
              bars: 8,
            },
          ]
        : structuredClone(INITIAL_STUDIO_PROJECT.chordChart),
      mastering: template
        ? MASTERING_PRESETS[template.masteringPreset] ?? INITIAL_STUDIO_PROJECT.mastering
        : INITIAL_STUDIO_PROJECT.mastering,
      updatedAt: new Date().toISOString(),
    };
    setSavedProjects((prev) => [newProj, ...prev]);
    setActiveProjectId(newId);
  };

  const handleRestoreProject = (restored: StudioProject) => {
    setSavedProjects((prev) => {
      const exists = prev.some((p) => p.id === restored.id);
      if (exists) return prev.map((p) => (p.id === restored.id ? restored : p));
      return [restored, ...prev];
    });
    setActiveProjectId(restored.id);
  };

  if (viewingShare && (shareParam || locParam)) {
    return (
      <ErrorBoundary>
        <SharedLinkViewer
          shareToken={shareParam}
          locToken={locParam}
          onExitToStudio={() => {
            window.history.replaceState({}, '', '/');
            setViewingShare(false);
          }}
        />
      </ErrorBoundary>
    );
  }

  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-[#0A0B0E] text-zinc-100 flex flex-col overflow-x-hidden">
        {/* Google Maps Platform Case A (Demo Key) Required Quota Banner */}
        {gmpQuotaExceeded && (
          <div className="bg-amber-50 border-b border-amber-200 text-amber-900 px-4 py-2.5 text-xs md:text-sm text-center sticky top-0 z-50 shadow-sm">
            <span>
              Google Maps Platform quota reached. If you are the app owner, visit{' '}
              <a
                href="https://developers.google.com/maps/ai/ai-studio?utm_campaign=gmp_mcp_codeassist_v1_aistudio#quota_exceeded_errors"
                target="_blank"
                rel="noopener noreferrer"
                className="underline font-semibold text-amber-950 hover:text-amber-800"
              >
                maps developer site
              </a>{' '}
              for instructions to update your account.
            </span>
          </div>
        )}

        {/* Top Bar Contract: 3 clean single-line zones */}
        <header className="h-14 sticky top-0 z-40 bg-[#0D0F14]/95 backdrop-blur-md border-b border-zinc-800 px-4 lg:px-6 flex items-center justify-between gap-8">
          {/* Zone 1: Single-line Brand Wordmark */}
          <a
            href="/"
            onClick={(e) => {
              e.preventDefault();
              setActiveTab('studio');
            }}
            className="text-lg font-display font-extrabold tracking-tight text-zinc-100 whitespace-nowrap shrink-0"
          >
            BEAT LABZ
          </a>

          {/* Zone 2: Master Transport Bar */}
          <div className="flex items-center gap-3 overflow-x-auto">
            <button
              type="button"
              onClick={togglePlay}
              aria-label={isPlaying ? 'Stop playback' : 'Start playback'}
              className={`px-3 py-1.5 rounded-lg text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0 ${
                isPlaying ? 'bg-amber-500 text-zinc-950' : 'bg-[#191C24] border border-zinc-700 text-zinc-100 hover:border-amber-500'
              }`}
            >
              {isPlaying ? <Square className="w-3.5 h-3.5 fill-current" /> : <Play className="w-3.5 h-3.5 fill-current" />}
              {isPlaying ? 'Stop' : 'Play'}
            </button>

            <label className="hidden sm:flex items-center gap-1.5 text-xs text-zinc-400 whitespace-nowrap shrink-0">
              <span>BPM</span>
              <input
                type="number"
                aria-label="Master Tempo BPM"
                min={40}
                max={240}
                value={project.bpm}
                onChange={(e) =>
                  updateProject((prev) => ({
                    ...prev,
                    bpm: Math.max(40, Math.min(240, Number(e.target.value) || 120)),
                  }))
                }
                className="w-16 bg-[#191C24] border border-zinc-700 rounded-md px-2 py-1 text-xs font-mono text-amber-400 tabular-nums"
              />
            </label>

            <button
              type="button"
              onClick={() => setMetronomeOn((m) => !m)}
              className={`hidden md:inline-flex px-2.5 py-1.5 rounded-lg text-xs font-medium border whitespace-nowrap shrink-0 ${
                metronomeOn ? 'bg-emerald-500/15 border-emerald-500/50 text-emerald-300' : 'bg-[#191C24] border-zinc-800 text-zinc-400'
              }`}
            >
              Click {metronomeOn ? 'On' : 'Off'}
            </button>

            {emergencyMuted && (
              <button
                type="button"
                onClick={toggleEmergencyMute}
                className="px-2.5 py-1.5 rounded-lg bg-red-600 text-white text-xs font-bold flex items-center gap-1 whitespace-nowrap shrink-0"
              >
                <VolumeX className="w-3.5 h-3.5" /> Muted
              </button>
            )}
          </div>

          {/* Zone 3: Single Primary Action */}
          <div className="flex items-center gap-2 shrink-0">
            <button
              type="button"
              onClick={persistProjectsLocally}
              className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-semibold flex items-center gap-1.5 whitespace-nowrap shrink-0"
            >
              <Save className="w-3.5 h-3.5" />
              {saveToast ? 'Saved' : 'Save Project'}
            </button>
          </div>
        </header>

        {/* Main Workspace Body */}
        <div className="flex-1 flex min-w-0">
          {/* Desktop Left Navigation Rail */}
          <aside className="hidden lg:flex flex-col w-60 shrink-0 border-r border-zinc-800 bg-[#0D0F14] p-4 space-y-1">
            <div className="text-[11px] font-medium text-zinc-500 px-3 pb-2">Workspaces</div>
            {NAV_ITEMS.map((item) => {
              const Icon = item.icon;
              const active = activeTab === item.id;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setActiveTab(item.id)}
                  className={`w-full px-3 py-2.5 rounded-lg text-sm font-medium flex items-center gap-3 transition-colors whitespace-nowrap ${
                    active
                      ? 'bg-amber-500/15 text-amber-400 border border-amber-500/30'
                      : 'text-zinc-400 hover:text-zinc-100 hover:bg-[#161922] border border-transparent'
                  }`}
                >
                  <Icon className="w-4 h-4 shrink-0" />
                  <span>{item.label}</span>
                </button>
              );
            })}
          </aside>

          {/* Main Scrollable Viewport */}
          <main className="flex-1 min-w-0 p-4 lg:p-6 pb-20 lg:pb-8 max-w-[1440px] mx-auto w-full overflow-x-hidden">
            {activeTab === 'studio' && (
              <StudioDawView
                project={project}
                onUpdateProject={updateProject}
                currentStep={currentStep}
                isPlaying={isPlaying}
                recordings={recordings}
                onAddRecording={(rec) =>
                  setRecordings((prev) => {
                    const exists = prev.some((r) => r.id === rec.id);
                    return exists ? prev.map((r) => (r.id === rec.id ? rec : r)) : [rec, ...prev];
                  })
                }
                onDeleteRecording={(id) => setRecordings((prev) => prev.filter((r) => r.id !== id))}
                savedProjects={savedProjects}
                onSelectProject={(p) => setActiveProjectId(p.id)}
                onCreateNewProject={createNewProject}
                onOpenConnectForShare={() => setActiveTab('connect')}
                canUndo={undoCount > 0}
                onUndo={undoLastEdit}
              />
            )}

            {activeTab === 'mastering' && (
              <MasteringLabView
                project={project}
                onUpdateMastering={(next) => updateProject((prev) => ({ ...prev, mastering: next }))}
                onExportComplete={(asset) => setExportedMixes((prev) => [asset, ...prev])}
              />
            )}

            {activeTab === 'live' && (
              <LivePerformanceView
                project={project}
                isPlaying={isPlaying}
                onTogglePlay={togglePlay}
                metronomeOn={metronomeOn}
                onToggleMetronome={() => setMetronomeOn((m) => !m)}
                emergencyMuted={emergencyMuted}
                onToggleEmergencyMute={toggleEmergencyMute}
                onUpdateBpm={(bpm) => updateProject((prev) => ({ ...prev, bpm }))}
                onUpdateTrackVolume={(trackId, volume) =>
                  updateProject((prev) => ({
                    ...prev,
                    tracks: prev.tracks.map((t) => (t.id === trackId ? { ...t, volume } : t)),
                  }))
                }
              />
            )}

            {activeTab === 'collaborate' && (
              <CollaborationStudioView
                project={project}
                roomId={collabRoomId}
                onChangeRoomId={setCollabRoomId}
                collaborators={collaborators}
                onUpdateRole={(id, role) =>
                  setCollaborators((prev) => prev.map((c) => (c.id === id ? { ...c, role } : c)))
                }
              />
            )}

            {activeTab === 'connect' && (
              <ConnectView
                project={project}
                recordings={recordings}
                exportedMixes={exportedMixes}
                collaborators={collaborators}
                onInviteCollaborator={(col) => setCollaborators((prev) => [col, ...prev])}
                collabRoomId={collabRoomId}
              />
            )}

            {activeTab === 'location' && <LocationShareView mapsApiKey={mapsApiKey} />}

            {activeTab === 'ai' && (
              <AiAssistantView
                project={project}
                onApplyBpm={(bpm) => updateProject((prev) => ({ ...prev, bpm }))}
              />
            )}

            {activeTab === 'cloud' && (
              <CloudStudioView
                user={user}
                authReady={authReady}
                project={project}
                onRestoreProject={handleRestoreProject}
                recordings={recordings}
              />
            )}

            {activeTab === 'learn' && <MusicEducationView />}
          </main>
        </div>

        {/* Mobile Bottom Thumb Navigation (<= 15% combined viewport height cap) */}
        <nav
          aria-label="Mobile Navigation"
          className="lg:hidden fixed bottom-0 left-0 right-0 z-40 h-14 bg-[#0D0F14]/95 backdrop-blur-md border-t border-zinc-800 grid grid-cols-5 items-center"
        >
          {[
            NAV_ITEMS[0], // Studio
            NAV_ITEMS[1], // Mastering
            NAV_ITEMS[2], // Stage
            NAV_ITEMS[6], // AI Coach
          ].map((item) => {
            const Icon = item.icon;
            const active = activeTab === item.id;
            return (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveTab(item.id)}
                className={`h-full flex flex-col items-center justify-center gap-0.5 text-[10px] font-medium ${
                  active ? 'text-amber-400' : 'text-zinc-400'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.shortLabel}</span>
              </button>
            );
          })}
          <button
            type="button"
            onClick={() => setMobileDrawerOpen(true)}
            aria-label="Open all BEAT LABZ modules"
            className="h-full flex flex-col items-center justify-center gap-0.5 text-[10px] font-medium text-zinc-400"
          >
            <Menu className="w-4 h-4" />
            <span>Modules</span>
          </button>
        </nav>

        {/* Mobile Full Module Sheet */}
        {mobileDrawerOpen && (
          <div className="lg:hidden fixed inset-0 z-50 bg-black/70 backdrop-blur-sm flex items-end">
            <div className="w-full bg-[#12141A] border-t border-zinc-800 rounded-t-3xl p-5 space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-zinc-100">All BEAT LABZ Modules</span>
                <button
                  type="button"
                  aria-label="Close modules menu"
                  onClick={() => setMobileDrawerOpen(false)}
                  className="p-2 rounded-lg text-zinc-400 hover:text-zinc-100"
                >
                  <X className="w-5 h-5" />
                </button>
              </div>
              <div className="grid grid-cols-3 gap-2.5 pb-4">
                {NAV_ITEMS.map((item) => {
                  const Icon = item.icon;
                  const active = activeTab === item.id;
                  return (
                    <button
                      key={item.id}
                      type="button"
                      onClick={() => {
                        setActiveTab(item.id);
                        setMobileDrawerOpen(false);
                      }}
                      className={`p-3 rounded-xl border flex flex-col items-center justify-center gap-1.5 text-xs font-medium min-h-[68px] ${
                        active
                          ? 'bg-amber-500/20 border-amber-500 text-amber-300'
                          : 'bg-[#191C24] border-zinc-800 text-zinc-300'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      <span className="text-center leading-tight">{item.shortLabel}</span>
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        )}
      </div>
    </ErrorBoundary>
  );
}

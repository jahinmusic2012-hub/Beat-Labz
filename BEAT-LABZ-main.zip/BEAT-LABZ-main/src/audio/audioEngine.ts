import type { MasteringSettings, SequencerTrack } from '../types/studio';
import { midiToFreq } from '../utils/musicTheory';
import { applyMasteringDSP, dbToLinear } from '../utils/audioExport';

class BeatLabzAudioEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private analyser: AnalyserNode | null = null;
  private reverbNode: ConvolverNode | null = null;
  private emergencyMuted = false;
  private masterVolume = 0.85;

  public ensureContext(): AudioContext {
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.value = this.emergencyMuted ? 0 : this.masterVolume;

      this.analyser = this.ctx.createAnalyser();
      this.analyser.fftSize = 1024;

      const compressor = this.ctx.createDynamicsCompressor();
      compressor.threshold.value = -8;
      compressor.ratio.value = 3;

      this.masterGain.connect(compressor);
      compressor.connect(this.analyser);
      this.analyser.connect(this.ctx.destination);

      this.reverbNode = this.createImpulseReverb(this.ctx);
      const reverbGain = this.ctx.createGain();
      reverbGain.gain.value = 0.25;
      this.reverbNode.connect(reverbGain);
      reverbGain.connect(this.masterGain);
    }
    if (this.ctx.state === 'suspended') {
      void this.ctx.resume();
    }
    return this.ctx;
  }

  private createImpulseReverb(ctx: BaseAudioContext): ConvolverNode {
    const length = Math.floor(ctx.sampleRate * 1.4);
    const impulse = ctx.createBuffer(2, length, ctx.sampleRate);
    for (let ch = 0; ch < 2; ch++) {
      const data = impulse.getChannelData(ch);
      for (let i = 0; i < length; i++) {
        data[i] = (Math.random() * 2 - 1) * Math.pow(1 - i / length, 2.6);
      }
    }
    const convolver = ctx.createConvolver();
    convolver.buffer = impulse;
    return convolver;
  }

  public setEmergencyMute(muted: boolean): void {
    this.emergencyMuted = muted;
    if (this.ctx && this.masterGain) {
      const now = this.ctx.currentTime;
      this.masterGain.gain.cancelScheduledValues(now);
      this.masterGain.gain.setTargetAtTime(muted ? 0 : this.masterVolume, now, 0.008);
    }
  }

  public isEmergencyMuted(): boolean {
    return this.emergencyMuted;
  }

  public setMasterVolume(vol: number): void {
    this.masterVolume = Math.max(0, Math.min(1.2, vol));
    if (this.ctx && this.masterGain && !this.emergencyMuted) {
      this.masterGain.gain.setTargetAtTime(this.masterVolume, this.ctx.currentTime, 0.015);
    }
  }

  public getAnalyserData(target: Uint8Array<ArrayBuffer>): boolean {
    if (!this.analyser) return false;
    this.analyser.getByteTimeDomainData(target);
    return true;
  }

  public getFrequencyData(target: Uint8Array<ArrayBuffer>): boolean {
    if (!this.analyser) return false;
    this.analyser.getByteFrequencyData(target);
    return true;
  }

  public getOutputPeakDb(): number {
    if (!this.analyser) return -60;
    const buf = new Float32Array(this.analyser.fftSize);
    this.analyser.getFloatTimeDomainData(buf);
    let peak = 0;
    for (let i = 0; i < buf.length; i++) {
      const a = Math.abs(buf[i]);
      if (a > peak) peak = a;
    }
    if (peak < 1e-4) return -60;
    return Math.max(-60, Math.min(0, Math.round(20 * Math.log10(peak) * 10) / 10));
  }

  public triggerMetronome(accent: boolean, time?: number): void {
    const ctx = this.ensureContext();
    if (!this.masterGain || this.emergencyMuted) return;
    const t = time ?? ctx.currentTime;
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(accent ? 1320 : 880, t);
    gain.gain.setValueAtTime(accent ? 0.25 : 0.14, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + 0.05);
    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(t);
    osc.stop(t + 0.06);
  }

  public triggerDrumVoice(
    voiceIndex: number,
    volume = 0.85,
    pan = 0,
    destination?: AudioNode,
    ctxOverride?: BaseAudioContext,
    timeOverride?: number
  ): void {
    const ctx = ctxOverride ?? this.ensureContext();
    const dest = destination ?? this.masterGain;
    if (!dest) return;
    const t = timeOverride ?? ctx.currentTime;

    const panner = ctx.createStereoPanner();
    panner.pan.value = Math.max(-1, Math.min(1, pan));
    panner.connect(dest);

    const v = Math.max(0.01, Math.min(1.2, volume));

    if (voiceIndex === 0) {
      // Kick
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(145, t);
      osc.frequency.exponentialRampToValueAtTime(42, t + 0.14);
      gain.gain.setValueAtTime(v, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.28);
      osc.connect(gain);
      gain.connect(panner);
      osc.start(t);
      osc.stop(t + 0.3);
    } else if (voiceIndex === 1) {
      // Snare (tone + filtered noise)
      const osc = ctx.createOscillator();
      const oscGain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(195, t);
      osc.frequency.exponentialRampToValueAtTime(110, t + 0.1);
      oscGain.gain.setValueAtTime(v * 0.45, t);
      oscGain.gain.exponentialRampToValueAtTime(0.001, t + 0.12);
      osc.connect(oscGain);
      oscGain.connect(panner);
      osc.start(t);
      osc.stop(t + 0.14);

      this.triggerNoiseBurst(ctx, panner, t, 0.16, 1600, 'highpass', v * 0.65);
    } else if (voiceIndex === 2) {
      // Closed Hat
      this.triggerNoiseBurst(ctx, panner, t, 0.055, 7200, 'highpass', v * 0.35);
    } else if (voiceIndex === 3) {
      // Open Hat
      this.triggerNoiseBurst(ctx, panner, t, 0.24, 6500, 'highpass', v * 0.38);
    } else if (voiceIndex === 4) {
      // Clap
      this.triggerNoiseBurst(ctx, panner, t, 0.13, 1800, 'bandpass', v * 0.6);
    } else {
      // Tom
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(175, t);
      osc.frequency.exponentialRampToValueAtTime(75, t + 0.18);
      gain.gain.setValueAtTime(v * 0.7, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.22);
      osc.connect(gain);
      gain.connect(panner);
      osc.start(t);
      osc.stop(t + 0.24);
    }
  }

  private triggerNoiseBurst(
    ctx: BaseAudioContext,
    dest: AudioNode,
    t: number,
    duration: number,
    cutoff: number,
    filterType: BiquadFilterType,
    volume: number
  ): void {
    const length = Math.max(1, Math.floor(ctx.sampleRate * duration));
    const buf = ctx.createBuffer(1, length, ctx.sampleRate);
    const data = buf.getChannelData(0);
    for (let i = 0; i < length; i++) {
      data[i] = Math.random() * 2 - 1;
    }
    const src = ctx.createBufferSource();
    src.buffer = buf;

    const filter = ctx.createBiquadFilter();
    filter.type = filterType;
    filter.frequency.setValueAtTime(cutoff, t);

    const gain = ctx.createGain();
    gain.gain.setValueAtTime(volume, t);
    gain.gain.exponentialRampToValueAtTime(0.001, t + duration);

    src.connect(filter);
    filter.connect(gain);
    gain.connect(dest);
    src.start(t);
    src.stop(t + duration + 0.01);
  }

  public triggerNote(
    midi: number,
    options: {
      preset?: string;
      volume?: number;
      pan?: number;
      durationSec?: number;
      reverbSend?: number;
      eqLow?: number;
      eqHigh?: number;
    } = {},
    destination?: AudioNode,
    ctxOverride?: BaseAudioContext,
    timeOverride?: number
  ): void {
    const ctx = ctxOverride ?? this.ensureContext();
    const dest = destination ?? this.masterGain;
    if (!dest) return;
    const t = timeOverride ?? ctx.currentTime;
    const dur = options.durationSec ?? 0.35;
    const freq = midiToFreq(midi);
    const vol = Math.max(0.01, Math.min(1.0, options.volume ?? 0.55));
    const preset = options.preset ?? 'warm-synth';

    const panner = ctx.createStereoPanner();
    panner.pan.value = Math.max(-1, Math.min(1, options.pan ?? 0));

    const lowShelf = ctx.createBiquadFilter();
    lowShelf.type = 'lowshelf';
    lowShelf.frequency.value = 180;
    lowShelf.gain.value = options.eqLow ?? 0;

    const highShelf = ctx.createBiquadFilter();
    highShelf.type = 'highshelf';
    highShelf.frequency.value = 4800;
    highShelf.gain.value = options.eqHigh ?? 0;

    const env = ctx.createGain();
    const osc1 = ctx.createOscillator();
    const osc2 = ctx.createOscillator();
    const filter = ctx.createBiquadFilter();
    filter.type = 'lowpass';

    if (preset === 'sub-bass') {
      osc1.type = 'sawtooth';
      osc2.type = 'sine';
      osc1.frequency.setValueAtTime(freq, t);
      osc2.frequency.setValueAtTime(freq * 0.5, t);
      filter.frequency.setValueAtTime(480, t);
      filter.frequency.exponentialRampToValueAtTime(180, t + dur);
    } else if (preset === 'worship-pad') {
      osc1.type = 'sawtooth';
      osc2.type = 'triangle';
      osc1.frequency.setValueAtTime(freq, t);
      osc2.frequency.setValueAtTime(freq * 1.004, t);
      filter.frequency.setValueAtTime(1900, t);
    } else if (preset === 'electric-piano') {
      osc1.type = 'sine';
      osc2.type = 'triangle';
      osc1.frequency.setValueAtTime(freq, t);
      osc2.frequency.setValueAtTime(freq * 2, t);
      filter.frequency.setValueAtTime(3200, t);
    } else {
      osc1.type = 'sawtooth';
      osc2.type = 'square';
      osc1.frequency.setValueAtTime(freq, t);
      osc2.frequency.setValueAtTime(freq * 0.997, t);
      filter.frequency.setValueAtTime(2600, t);
    }

    const attack = preset === 'worship-pad' ? 0.08 : 0.012;
    env.gain.setValueAtTime(0.0001, t);
    env.gain.linearRampToValueAtTime(vol * 0.35, t + attack);
    env.gain.exponentialRampToValueAtTime(0.001, t + dur);

    osc1.connect(filter);
    osc2.connect(filter);
    filter.connect(env);
    env.connect(lowShelf);
    lowShelf.connect(highShelf);
    highShelf.connect(panner);
    panner.connect(dest);

    if (!ctxOverride && this.reverbNode && (options.reverbSend ?? 0) > 0.02) {
      const sendGain = ctx.createGain();
      sendGain.gain.value = Math.min(0.7, options.reverbSend ?? 0);
      panner.connect(sendGain);
      sendGain.connect(this.reverbNode);
    }

    osc1.start(t);
    osc2.start(t);
    osc1.stop(t + dur + 0.05);
    osc2.stop(t + dur + 0.05);
  }

  public triggerChord(midis: number[], durationSec = 0.75, preset = 'electric-piano'): void {
    const ctx = this.ensureContext();
    const now = ctx.currentTime;
    midis.forEach((m, idx) => {
      this.triggerNote(m, { preset, volume: 0.42, durationSec, reverbSend: 0.25 }, undefined, ctx, now + idx * 0.018);
    });
  }

  public async renderProjectMixToStereo(
    tracks: SequencerTrack[],
    bpm: number,
    bars = 2,
    mastering?: MasteringSettings,
    swingPct = 0
  ): Promise<{ left: Float32Array; right: Float32Array; sampleRate: number }> {
    const sampleRate = 44100;
    const stepDur = 60 / Math.max(30, Math.min(300, bpm)) / 4;
    const swingOffset = ((Math.max(0, Math.min(60, swingPct)) / 100) * stepDur) * 0.5;
    const totalSteps = 16 * bars;
    const tailSec = 0.75;
    const totalLength = Math.ceil((totalSteps * stepDur + tailSec) * sampleRate);

    const offline = new OfflineAudioContext(2, totalLength, sampleRate);
    const mixBus = offline.createGain();
    mixBus.gain.value = 0.88;
    mixBus.connect(offline.destination);

    const hasSolo = tracks.some((t) => t.solo);
    const activeTracks = tracks.filter((t) => (hasSolo ? t.solo : !t.muted));

    for (const track of activeTracks) {
      for (let bar = 0; bar < bars; bar++) {
        for (let step = 0; step < 16; step++) {
          if (!track.steps[step]) continue;
          const t = (bar * 16 + step) * stepDur + (step % 2 === 1 ? swingOffset : 0);
          if (track.kind === 'drums') {
            this.triggerDrumVoice(track.notes[step] ?? 0, track.volume, track.pan, mixBus, offline, t);
          } else {
            this.triggerNote(
              track.notes[step] ?? 60,
              {
                preset: track.instrumentPreset,
                volume: track.volume,
                pan: track.pan,
                durationSec: stepDur * 1.8,
                eqLow: track.eqLow,
                eqHigh: track.eqHigh,
              },
              mixBus,
              offline,
              t
            );
          }
        }
      }
    }

    const rendered = await offline.startRendering();
    let left: Float32Array = new Float32Array(rendered.getChannelData(0));
    let right: Float32Array = new Float32Array(rendered.getChannelData(1));

    if (mastering) {
      const mastered = applyMasteringDSP(left, right, sampleRate, mastering);
      left = mastered.left;
      right = mastered.right;
    }

    return { left, right, sampleRate };
  }

  public playStereoBuffer(left: Float32Array, right: Float32Array, sampleRate: number): AudioBufferSourceNode {
    const ctx = this.ensureContext();
    const buf = ctx.createBuffer(2, left.length, sampleRate);
    buf.copyToChannel(new Float32Array(left), 0);
    buf.copyToChannel(new Float32Array(right), 1);
    const src = ctx.createBufferSource();
    src.buffer = buf;
    const gain = ctx.createGain();
    gain.gain.value = dbToLinear(0);
    src.connect(gain);
    if (this.masterGain) {
      gain.connect(this.masterGain);
    } else {
      gain.connect(ctx.destination);
    }
    src.start();
    return src;
  }
}

export const audioEngine = new BeatLabzAudioEngine();

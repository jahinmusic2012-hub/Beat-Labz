import React, { useState } from 'react';
import { BookOpen, Ear, Music, Guitar, Piano, Activity, Trophy } from 'lucide-react';
import {
  CHORD_QUALITIES,
  NOTE_NAMES,
  SCALES,
  getChordNotes,
  getGuitarVoicing,
  getScaleNotes,
  midiToNoteName,
} from '../utils/musicTheory';
import { audioEngine } from '../audio/audioEngine';
import { INITIAL_PRACTICE_LOGS } from '../data/defaultStudio';
import type { PracticeSessionLog } from '../types/studio';

const PRACTICE_STORAGE_KEY = 'beatlabz_practice_logs_v1';

const PIANO_OCTAVE = Array.from({ length: 17 }, (_, i) => 60 + i); // C4..E5
const BLACK_SET = new Set([1, 3, 6, 8, 10]);

const THEORY_LESSONS = [
  {
    id: 'diatonic',
    title: 'Diatonic Harmony & Nashville Numbers',
    summary: 'In any major key, chords I, IV, and V are major; ii, iii, and vi are minor; vii° is diminished. Using numbers (1-5-6-4) lets you transpose instantly on stage.',
    example: 'Key of C: I = C, IV = F, V = G, vi = Am',
  },
  {
    id: 'voice-leading',
    title: 'Smooth Voice Leading & Slash Chords',
    summary: 'Inversions like G/B or C/E keep bass movement stepwise rather than jumping by fourths or fifths, creating emotional warmth in ballads and worship arrangements.',
    example: 'Progression: C → G/B → Am7 → G → Fmaj7',
  },
  {
    id: 'modal-interchange',
    title: 'Modal Interchange (Borrowed Chords)',
    summary: 'Borrowing the minor iv (Fm) or flat-VI (Ab) into a major key creates cinematic lift before resolving back to the tonic I chord.',
    example: 'Key of C: C → F → Fm6 → C',
  },
];

const INTERVAL_QUIZ = [
  { label: 'Major 3rd', semitones: 4 },
  { label: 'Perfect 4th', semitones: 5 },
  { label: 'Perfect 5th', semitones: 7 },
  { label: 'Minor 7th', semitones: 10 },
  { label: 'Octave', semitones: 12 },
];

export const MusicEducationView: React.FC = () => {
  const [eduTab, setEduTab] = useState<'keyboard' | 'guitar' | 'ear' | 'rhythm' | 'theory'>('keyboard');
  const [selectedRoot, setSelectedRoot] = useState<string>('C');
  const [selectedQuality, setSelectedQuality] = useState<string>('maj7');
  const [selectedScale, setSelectedScale] = useState<string>('major');

  // Ear training state
  const [quizTarget, setQuizTarget] = useState(() => INTERVAL_QUIZ[2]);
  const [quizFeedback, setQuizFeedback] = useState<string | null>(null);
  const [quizCorrect, setQuizCorrect] = useState(0);
  const [quizAttempts, setQuizAttempts] = useState(0);

  // Rhythm training state
  const [rhythmBpm, setRhythmBpm] = useState(96);
  const [rhythmTaps, setRhythmTaps] = useState<number[]>([]);
  const [rhythmAccuracy, setRhythmAccuracy] = useState<number | null>(null);

  // Practice tracker
  const [logs, setLogs] = useState<PracticeSessionLog[]>(() => {
    try {
      const saved = localStorage.getItem(PRACTICE_STORAGE_KEY);
      if (saved) return JSON.parse(saved) as PracticeSessionLog[];
    } catch {
      // ignore
    }
    return INITIAL_PRACTICE_LOGS;
  });

  const chordInfo = getChordNotes(selectedRoot, selectedQuality, 4);
  const scaleInfo = getScaleNotes(selectedRoot, selectedScale, 4);
  const guitarVoicing = getGuitarVoicing(chordInfo.symbol);
  const highlightedPitchClasses = new Set(chordInfo.midis.map((m) => m % 12));

  const recordPractice = (module: PracticeSessionLog['module'], topic: string, scorePct: number) => {
    const entry: PracticeSessionLog = {
      id: `pr_${Date.now()}`,
      module,
      topic,
      scorePct,
      durationSec: 120,
      completedAt: new Date().toISOString(),
    };
    const next = [entry, ...logs].slice(0, 20);
    setLogs(next);
    localStorage.setItem(PRACTICE_STORAGE_KEY, JSON.stringify(next));
  };

  const playIntervalPrompt = () => {
    const rootMidi = 60;
    audioEngine.triggerNote(rootMidi, { preset: 'electric-piano', durationSec: 0.45 });
    setTimeout(() => {
      audioEngine.triggerNote(rootMidi + quizTarget.semitones, { preset: 'electric-piano', durationSec: 0.55 });
    }, 380);
  };

  const submitEarGuess = (semitones: number) => {
    const nextAttempts = quizAttempts + 1;
    setQuizAttempts(nextAttempts);
    if (semitones === quizTarget.semitones) {
      const nextCorrect = quizCorrect + 1;
      setQuizCorrect(nextCorrect);
      setQuizFeedback(`Correct! That was ${quizTarget.label}.`);
      const nextTarget = INTERVAL_QUIZ[Math.floor(Math.random() * INTERVAL_QUIZ.length)];
      setQuizTarget(nextTarget);
      if (nextAttempts % 5 === 0) {
        recordPractice('ear_training', 'Interval Recognition Drill', Math.round((nextCorrect / nextAttempts) * 100));
      }
    } else {
      setQuizFeedback(`Not quite — listen again for the ${quizTarget.label}.`);
    }
  };

  const handleRhythmTap = () => {
    audioEngine.triggerMetronome(true);
    const now = performance.now();
    const updated = [...rhythmTaps, now].slice(-5);
    setRhythmTaps(updated);
    if (updated.length >= 3) {
      const targetIntervalMs = 60000 / rhythmBpm;
      const diffs: number[] = [];
      for (let i = 1; i < updated.length; i++) {
        diffs.push(Math.abs(updated[i] - updated[i - 1] - targetIntervalMs));
      }
      const avgErr = diffs.reduce((a, b) => a + b, 0) / diffs.length;
      const accuracy = Math.max(0, Math.min(100, Math.round(100 - (avgErr / targetIntervalMs) * 100)));
      setRhythmAccuracy(accuracy);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-[#12141A] border border-zinc-800 rounded-xl p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-zinc-100">Music Education & Practice Lab</h1>
          <p className="text-sm text-zinc-400">
            Interactive keyboard & guitar fretboard trainer, chord/scale library, ear training, rhythm drill, and practice tracker
          </p>
        </div>

        <div className="flex flex-wrap gap-1 p-1 bg-[#0D0F14] rounded-lg border border-zinc-800">
          {[
            { id: 'keyboard', label: 'Keyboard & Chords', icon: Piano },
            { id: 'guitar', label: 'Guitar & Scales', icon: Guitar },
            { id: 'ear', label: 'Ear Training', icon: Ear },
            { id: 'rhythm', label: 'Rhythm Drill', icon: Activity },
            { id: 'theory', label: 'Theory Lessons', icon: BookOpen },
          ].map((t) => (
            <button
              key={t.id}
              type="button"
              onClick={() => setEduTab(t.id as typeof eduTab)}
              className={`px-3 py-1.5 rounded-md text-xs font-medium flex items-center gap-1.5 whitespace-nowrap ${
                eduTab === t.id ? 'bg-amber-500 text-zinc-950 font-semibold' : 'text-zinc-400 hover:text-zinc-100'
              }`}
            >
              <t.icon className="w-3.5 h-3.5" /> {t.label}
            </button>
          ))}
        </div>
      </div>

      {/* Root & Quality Selector Bar */}
      {(eduTab === 'keyboard' || eduTab === 'guitar') && (
        <div className="bg-[#12141A] border border-zinc-800 rounded-xl p-4 flex flex-wrap items-center gap-3">
          <div className="flex flex-wrap gap-1">
            {NOTE_NAMES.map((n) => (
              <button
                key={n}
                type="button"
                onClick={() => setSelectedRoot(n)}
                className={`px-2.5 py-1.5 rounded-md text-xs font-mono font-semibold ${
                  selectedRoot === n ? 'bg-amber-500 text-zinc-950' : 'bg-[#191C24] text-zinc-300 hover:bg-zinc-800'
                }`}
              >
                {n}
              </button>
            ))}
          </div>

          <select
            aria-label="Chord quality"
            value={selectedQuality}
            onChange={(e) => setSelectedQuality(e.target.value)}
            className="bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-1.5 text-xs text-zinc-100"
          >
            {CHORD_QUALITIES.map((q) => (
              <option key={q.id} value={q.id}>{q.label}</option>
            ))}
          </select>

          <select
            aria-label="Scale selector"
            value={selectedScale}
            onChange={(e) => setSelectedScale(e.target.value)}
            className="bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-1.5 text-xs text-zinc-100"
          >
            {SCALES.map((s) => (
              <option key={s.id} value={s.id}>{s.name}</option>
            ))}
          </select>
        </div>
      )}

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-[#12141A] border border-zinc-800 rounded-xl p-5 space-y-5">
          {eduTab === 'keyboard' && (
            <>
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="text-lg font-bold text-zinc-100">
                    Chord: <span className="text-amber-400 font-mono">{chordInfo.symbol}</span>
                  </h2>
                  <p className="text-xs text-zinc-400 font-mono">Notes: {chordInfo.names.join(' – ')}</p>
                </div>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => audioEngine.triggerChord(chordInfo.midis, 0.9, 'electric-piano')}
                    className="px-3.5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-semibold flex items-center gap-1.5"
                  >
                    <Music className="w-3.5 h-3.5" /> Play Chord
                  </button>
                  <button
                    type="button"
                    onClick={() => recordPractice('keyboard', `${chordInfo.symbol} Voicing`, 100)}
                    className="px-3.5 py-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-zinc-100"
                  >
                    Log Practice
                  </button>
                </div>
              </div>

              {/* Realistic Two-Tier Interactive Keyboard (C4..E5) */}
              <div className="studio-well rounded-xl p-3 overflow-x-auto">
                <div className="relative h-40 min-w-[540px] select-none">
                  {/* White Keys */}
                  <div className="grid grid-cols-10 gap-1 h-full">
                    {PIANO_OCTAVE.filter((m) => !BLACK_SET.has(m % 12)).map((midi) => {
                      const inChord = highlightedPitchClasses.has(midi % 12);
                      return (
                        <button
                          key={midi}
                          type="button"
                          onClick={() => audioEngine.triggerNote(midi, { preset: 'electric-piano', durationSec: 0.55 })}
                          className={`h-full rounded-b-lg rounded-t-sm border text-[11px] font-mono flex flex-col justify-end items-center pb-2.5 transition-all active:translate-y-[1px] ${
                            inChord
                              ? 'bg-amber-400 border-amber-200 text-zinc-950 font-bold shadow-[inset_0_-3px_0_rgba(180,83,9,0.4)]'
                              : 'bg-gradient-to-b from-zinc-100 to-zinc-200 border-zinc-400 text-zinc-800 hover:from-white hover:to-amber-50'
                          }`}
                        >
                          {midiToNoteName(midi)}
                        </button>
                      );
                    })}
                  </div>

                  {/* Raised Black Keys */}
                  {[
                    { midi: 61, leftPct: 7.2 },
                    { midi: 63, leftPct: 17.2 },
                    { midi: 66, leftPct: 37.2 },
                    { midi: 68, leftPct: 47.2 },
                    { midi: 70, leftPct: 57.2 },
                    { midi: 73, leftPct: 77.2 },
                    { midi: 75, leftPct: 87.2 },
                  ].map(({ midi, leftPct }) => {
                    const inChord = highlightedPitchClasses.has(midi % 12);
                    return (
                      <button
                        key={midi}
                        type="button"
                        onClick={() => audioEngine.triggerNote(midi, { preset: 'electric-piano', durationSec: 0.55 })}
                        style={{ left: `${leftPct}%`, width: '5.8%' }}
                        className={`absolute top-0 h-[60%] rounded-b-md border text-[10px] font-mono flex flex-col justify-end items-center pb-2 z-10 shadow-md transition-all active:translate-y-[1px] ${
                          inChord
                            ? 'bg-amber-500 border-amber-300 text-zinc-950 font-bold'
                            : 'bg-gradient-to-b from-zinc-800 to-zinc-950 border-zinc-700 text-zinc-300 hover:border-amber-500'
                        }`}
                      >
                        {midiToNoteName(midi)}
                      </button>
                    );
                  })}
                </div>
              </div>
            </>
          )}

          {eduTab === 'guitar' && (
            <>
              <div className="flex flex-wrap items-center justify-between gap-3">
                <div>
                  <h2 className="text-lg font-bold text-zinc-100">
                    Guitar Voicing: <span className="text-amber-400 font-mono">{guitarVoicing.symbol}</span>
                  </h2>
                  <p className="text-xs text-zinc-400 font-mono">
                    Scale ({selectedRoot} {SCALES.find((s) => s.id === selectedScale)?.name}): {scaleInfo.names.join(' – ')}
                  </p>
                </div>
                <div className="flex gap-2">
                  <button
                    type="button"
                    onClick={() => audioEngine.triggerChord(guitarVoicing.midis, 0.9, 'warm-synth')}
                    className="px-3.5 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-semibold"
                  >
                    Strum Chord
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      scaleInfo.midis.forEach((m, i) => {
                        setTimeout(() => audioEngine.triggerNote(m, { preset: 'electric-piano', durationSec: 0.3 }), i * 220);
                      });
                      recordPractice('guitar', `${selectedRoot} ${selectedScale} Scale`, 95);
                    }}
                    className="px-3.5 py-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-zinc-100"
                  >
                    Play Scale
                  </button>
                </div>
              </div>

              {/* 6-String Fretboard Grid */}
              <div className="space-y-2 bg-[#0D0F14] border border-zinc-800 rounded-xl p-4">
                {['e (1)', 'B (2)', 'G (3)', 'D (4)', 'A (5)', 'E (6)'].map((strLabel, visualIdx) => {
                  const strIdx = 5 - visualIdx;
                  const chosenFret = guitarVoicing.frets[strIdx];
                  return (
                    <div key={strLabel} className="grid grid-cols-7 items-center gap-2">
                      <span className="text-xs font-mono text-zinc-400">{strLabel}</span>
                      {[0, 1, 2, 3, 4, 5].map((fret) => {
                        const isActive = chosenFret === fret;
                        return (
                          <div
                            key={fret}
                            className={`h-8 rounded border flex items-center justify-center text-xs font-mono ${
                              isActive
                                ? 'bg-amber-500 border-amber-300 text-zinc-950 font-bold'
                                : chosenFret === null && fret === 0
                                  ? 'bg-red-500/10 border-red-500/30 text-red-400'
                                  : 'bg-[#191C24] border-zinc-800 text-zinc-600'
                            }`}
                          >
                            {isActive ? `F${fret}` : chosenFret === null && fret === 0 ? 'X' : fret === 0 ? 'O' : ''}
                          </div>
                        );
                      })}
                    </div>
                  );
                })}
              </div>
            </>
          )}

          {eduTab === 'ear' && (
            <div className="space-y-5">
              <div className="flex items-center justify-between">
                <h2 className="text-lg font-bold text-zinc-100">Interval Ear-Training Drill</h2>
                <span className="text-sm font-mono text-emerald-400 tabular-nums">
                  Score: {quizCorrect} / {quizAttempts}
                </span>
              </div>
              <button
                type="button"
                onClick={playIntervalPrompt}
                className="px-5 py-3 rounded-xl bg-amber-500 hover:bg-amber-400 text-zinc-950 text-sm font-semibold"
              >
                Play Interval Reference
              </button>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
                {INTERVAL_QUIZ.map((opt) => (
                  <button
                    key={opt.semitones}
                    type="button"
                    onClick={() => submitEarGuess(opt.semitones)}
                    className="py-3 px-4 rounded-xl bg-[#191C24] hover:bg-zinc-800 border border-zinc-700 text-sm font-medium text-zinc-100"
                  >
                    {opt.label}
                  </button>
                ))}
              </div>
              {quizFeedback && <p className="text-sm text-amber-300">{quizFeedback}</p>}
            </div>
          )}

          {eduTab === 'rhythm' && (
            <div className="space-y-5">
              <div className="flex flex-wrap items-center justify-between gap-3">
                <h2 className="text-lg font-bold text-zinc-100">Rhythm Timing Trainer</h2>
                <label className="flex items-center gap-2 text-xs text-zinc-300 font-mono">
                  Target BPM:
                  <input
                    type="number"
                    min={50}
                    max={180}
                    value={rhythmBpm}
                    onChange={(e) => {
                      setRhythmBpm(Number(e.target.value));
                      setRhythmTaps([]);
                      setRhythmAccuracy(null);
                    }}
                    className="w-16 bg-[#191C24] border border-zinc-700 rounded px-2 py-1 text-zinc-100"
                  />
                </label>
              </div>
              <p className="text-xs text-zinc-400">
                Tap steadily at {rhythmBpm} BPM (one beat every {Math.round(60000 / rhythmBpm)} ms) to measure your internal timing accuracy.
              </p>
              <div className="flex items-center gap-4">
                <button
                  type="button"
                  onClick={handleRhythmTap}
                  className="px-8 py-6 rounded-2xl bg-amber-500 hover:bg-amber-400 active:scale-95 text-zinc-950 text-base font-bold transition-transform"
                >
                  TAP BEAT
                </button>
                {rhythmAccuracy !== null && (
                  <div className="space-y-1">
                    <div className="text-2xl font-mono font-bold text-emerald-400 tabular-nums">{rhythmAccuracy}% Accurate</div>
                    <button
                      type="button"
                      onClick={() => recordPractice('rhythm', `${rhythmBpm} BPM Steadiness`, rhythmAccuracy)}
                      className="text-xs text-amber-400 hover:underline"
                    >
                      Save Score to Practice Log
                    </button>
                  </div>
                )}
              </div>
            </div>
          )}

          {eduTab === 'theory' && (
            <div className="space-y-4">
              <h2 className="text-lg font-bold text-zinc-100">Music Theory & Arrangement Lessons</h2>
              {THEORY_LESSONS.map((lesson) => (
                <div key={lesson.id} className="p-4 rounded-xl bg-[#191C24] border border-zinc-800 space-y-2">
                  <div className="flex items-center justify-between gap-2">
                    <h3 className="text-sm font-semibold text-amber-400">{lesson.title}</h3>
                    <button
                      type="button"
                      onClick={() => recordPractice('theory', lesson.title, 100)}
                      className="text-xs text-emerald-400 hover:underline"
                    >
                      Mark Complete
                    </button>
                  </div>
                  <p className="text-xs text-zinc-300 leading-relaxed">{lesson.summary}</p>
                  <div className="text-xs font-mono text-zinc-400 bg-[#0D0F14] px-3 py-2 rounded border border-zinc-800">
                    {lesson.example}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        {/* Practice Tracker */}
        <div className="bg-[#12141A] border border-zinc-800 rounded-xl p-5 space-y-4">
          <h2 className="text-base font-semibold text-zinc-100 flex items-center gap-2">
            <Trophy className="w-4 h-4 text-amber-400" /> Practice Tracker
          </h2>
          <div className="space-y-2.5 max-h-96 overflow-y-auto pr-1">
            {logs.map((log) => (
              <div key={log.id} className="p-3 rounded-lg bg-[#191C24] border border-zinc-800 space-y-1">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-semibold text-zinc-100">{log.topic}</span>
                  <span className="font-mono text-emerald-400 tabular-nums">{log.scorePct}%</span>
                </div>
                <div className="text-[11px] text-zinc-400">
                  {log.module.replace('_', ' ')} · {new Date(log.completedAt).toLocaleDateString()}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

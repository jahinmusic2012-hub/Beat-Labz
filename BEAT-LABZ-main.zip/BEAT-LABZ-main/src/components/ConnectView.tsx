import React, { useState } from 'react';
import {
  Share2,
  Copy,
  Check,
  MessageCircle,
  Lock,
  Globe,
  UserPlus,
  Music,
  Download,
} from 'lucide-react';
import type { CollaboratorProfile, RecordedTake, StudioProject } from '../types/studio';
import { buildMidiFileBytes } from '../utils/musicTheory';
import { buildWhatsAppUrl, formatBytes } from '../utils/shareUtils';

interface ConnectViewProps {
  project: StudioProject;
  recordings: RecordedTake[];
  exportedMixes: Array<{ id: string; name: string; format: 'WAV' | 'MP3'; sizeBytes: number; objectUrl?: string; blobUrl: string }>;
  collaborators: CollaboratorProfile[];
  onInviteCollaborator: (c: CollaboratorProfile) => void;
  collabRoomId: string;
}

type ShareCategory =
  | 'project'
  | 'mix'
  | 'recording'
  | 'midi'
  | 'chordchart'
  | 'invitation'
  | 'songbook'
  | 'session';

export const ConnectView: React.FC<ConnectViewProps> = ({
  project,
  recordings,
  exportedMixes,
  collaborators,
  onInviteCollaborator,
  collabRoomId,
}) => {
  const [shareCategory, setShareCategory] = useState<ShareCategory>('project');
  const [isPrivateShare, setIsPrivateShare] = useState(true);
  const [passcode, setPasscode] = useState('');
  const [generatedLink, setGeneratedLink] = useState<string | null>(null);
  const [shareStatus, setShareStatus] = useState<string | null>(null);
  const [shareError, setShareError] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  const [inviteName, setInviteName] = useState('');
  const [inviteEmail, setInviteEmail] = useState('');
  const [inviteInstrument, setInviteInstrument] = useState('Acoustic Guitar');
  const [inviteRole, setInviteRole] = useState<'editor' | 'commenter' | 'viewer'>('editor');

  const webShareSupported = typeof navigator !== 'undefined' && typeof navigator.share === 'function';

  const buildShareSummaryText = (linkUrl?: string) => {
    const base = linkUrl || window.location.origin;
    if (shareCategory === 'chordchart') {
      const chartText = project.chordChart.map((c) => `${c.section}: ${c.chords.join(' | ')}`).join('\n');
      return `BEAT LABZ Chord Chart — ${project.title} (${project.musicalKey}, ${project.bpm} BPM)\n${chartText}\nOpen: ${base}`;
    }
    if (shareCategory === 'songbook') {
      return `BEAT LABZ Songbook — ${project.songbook.title} by ${project.songbook.artist}\nKey: ${project.musicalKey} · Capo ${project.songbook.capo}\nNotes: ${project.songbook.notes}\nOpen: ${base}`;
    }
    if (shareCategory === 'session') {
      return `Join my live BEAT LABZ Studio Session (${collabRoomId}) for "${project.title}" at ${project.bpm} BPM!\nLink: ${base}`;
    }
    if (shareCategory === 'invitation') {
      return `You are invited to collaborate on "${project.title}" in BEAT LABZ.\nOpen Link: ${base}`;
    }
    if (shareCategory === 'midi') {
      return `BEAT LABZ MIDI Pattern — ${project.title} (${project.bpm} BPM)\nOpen: ${base}`;
    }
    if (shareCategory === 'mix') {
      const mixName = exportedMixes[0]?.name ?? `${project.title} Master`;
      return `Listen to my mastered mix "${mixName}" from BEAT LABZ!\nLink: ${base}`;
    }
    if (shareCategory === 'recording') {
      const recName = recordings[0]?.name ?? `${project.title} Studio Take`;
      return `Listen to my studio recording "${recName}" from BEAT LABZ!\nLink: ${base}`;
    }
    return `BEAT LABZ Project: "${project.title}" (${project.musicalKey} · ${project.bpm} BPM)\nLink: ${base}`;
  };

  const generateSecureShareLink = async () => {
    setShareError(null);
    setShareStatus('Creating secure share link...');
    try {
      const payload: Record<string, unknown> = {
        projectTitle: project.title,
        bpm: project.bpm,
        musicalKey: project.musicalKey,
        chordChart: project.chordChart,
        songbook: project.songbook,
        roomId: collabRoomId,
        latestMixUrl: exportedMixes[0]?.objectUrl ?? null,
        latestRecordingUrl: recordings[0]?.objectUrl ?? null,
      };
      const res = await fetch('/api/shares', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          kind: shareCategory,
          title: `${project.title} (${shareCategory})`,
          isPrivate: isPrivateShare,
          passcode: isPrivateShare ? passcode : '',
          payload,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Failed to create share link.');
      const fullUrl = `${window.location.origin}${data.sharePath}`;
      setGeneratedLink(fullUrl);
      setShareStatus(
        isPrivateShare
          ? 'Private secure link generated (expires in 7 days).'
          : 'Shareable link generated (expires in 7 days).'
      );
      return fullUrl;
    } catch (err) {
      setShareError(err instanceof Error ? err.message : 'Unable to generate share link.');
      setShareStatus(null);
      return null;
    }
  };

  const handleCopyLink = async () => {
    const url = generatedLink ?? (await generateSecureShareLink());
    if (!url) return;
    await navigator.clipboard.writeText(url);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleNativeShare = async () => {
    const url = generatedLink ?? (await generateSecureShareLink());
    if (!url) return;
    const text = buildShareSummaryText(url);

    if (webShareSupported) {
      try {
        await navigator.share({
          title: `BEAT LABZ — ${project.title}`,
          text,
          url,
        });
        setShareStatus('Shared via device native share sheet.');
        return;
      } catch (err) {
        if ((err as Error).name === 'AbortError') return;
      }
    }
    // Fallback to WhatsApp URL when Web Share API is unavailable
    window.open(buildWhatsAppUrl(text), '_blank', 'noopener,noreferrer');
  };

  const handleWhatsAppShare = async () => {
    const url = generatedLink ?? (await generateSecureShareLink());
    const text = buildShareSummaryText(url ?? undefined);
    window.open(buildWhatsAppUrl(text), '_blank', 'noopener,noreferrer');
  };

  const exportAndShareMidi = async () => {
    const bytes = buildMidiFileBytes(project.tracks, project.bpm);
    const fileName = `${project.title.toLowerCase().replace(/[^a-z0-9]+/g, '-')}.mid`;
    const blob = new Blob([new Uint8Array(bytes)], { type: 'audio/midi' });
    if (webShareSupported && typeof navigator.canShare === 'function') {
      const file = new File([blob], fileName, { type: 'audio/midi' });
      if (navigator.canShare({ files: [file] })) {
        try {
          await navigator.share({ title: fileName, files: [file] });
          return;
        } catch {
          // fallback to download
        }
      }
    }
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    a.click();
    URL.revokeObjectURL(url);
    setShareStatus(`Downloaded ${fileName} (${bytes.byteLength} bytes) for sharing.`);
  };

  const submitInvitation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!inviteName.trim() || !inviteEmail.trim()) return;
    onInviteCollaborator({
      id: `col_${Date.now()}`,
      name: inviteName.trim(),
      email: inviteEmail.trim(),
      role: inviteRole,
      instrument: inviteInstrument.trim() || 'Session Musician',
      online: false,
    });
    setInviteName('');
    setInviteEmail('');
    setShareStatus(`Invitation prepared for ${inviteName.trim()} (${inviteEmail.trim()}).`);
  };

  return (
    <div className="space-y-6">
      <div className="bg-[#12141A] border border-zinc-800 rounded-xl p-5">
        <h1 className="text-xl font-bold text-zinc-100">BEAT LABZ Connect</h1>
        <p className="text-sm text-zinc-400">
          Share mixes, recorded audio, MIDI files, chord charts, songbook entries, and studio invitations via Native Share or WhatsApp
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Share Center */}
        <div className="lg:col-span-2 bg-[#12141A] border border-zinc-800 rounded-xl p-5 space-y-5">
          <h2 className="text-base font-semibold text-zinc-100">1. Choose What to Share</h2>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
            {[
              { id: 'project', label: 'Project Link' },
              { id: 'mix', label: 'Exported Mix' },
              { id: 'recording', label: 'Recorded Audio' },
              { id: 'midi', label: 'MIDI File' },
              { id: 'chordchart', label: 'Chord Chart' },
              { id: 'songbook', label: 'Songbook Entry' },
              { id: 'invitation', label: 'Project Invite' },
              { id: 'session', label: 'Studio Session' },
            ].map((item) => (
              <button
                key={item.id}
                type="button"
                onClick={() => {
                  setShareCategory(item.id as ShareCategory);
                  setGeneratedLink(null);
                }}
                className={`px-3 py-2.5 rounded-lg text-xs font-medium border text-left transition-colors ${
                  shareCategory === item.id
                    ? 'bg-amber-500 text-zinc-950 border-amber-400 font-semibold'
                    : 'bg-[#191C24] border-zinc-800 text-zinc-300 hover:border-zinc-600'
                }`}
              >
                {item.label}
              </button>
            ))}
          </div>

          {/* Privacy & Passcode Protection */}
          <div className="p-4 rounded-xl bg-[#191C24] border border-zinc-800 space-y-3">
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div className="flex items-center gap-2 text-sm font-medium text-zinc-100">
                {isPrivateShare ? <Lock className="w-4 h-4 text-amber-400" /> : <Globe className="w-4 h-4 text-emerald-400" />}
                <span>{isPrivateShare ? 'Private Backend Share Link' : 'Standard Share Link'}</span>
              </div>
              <button
                type="button"
                onClick={() => setIsPrivateShare((v) => !v)}
                className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-zinc-200"
              >
                Switch to {isPrivateShare ? 'Standard' : 'Private'}
              </button>
            </div>
            {isPrivateShare && (
              <label className="block space-y-1">
                <span className="text-xs text-zinc-400">Optional Access Passcode (for private project verification)</span>
                <input
                  type="password"
                  placeholder="Leave blank for token-only privacy or enter passcode"
                  value={passcode}
                  onChange={(e) => setPasscode(e.target.value)}
                  className="w-full bg-[#0D0F14] border border-zinc-700 rounded-lg px-3 py-2 text-xs text-zinc-100"
                />
              </label>
            )}
          </div>

          {/* Preview Message */}
          <div className="bg-[#0D0F14] border border-zinc-800 rounded-lg p-3 text-xs font-mono text-zinc-300 whitespace-pre-wrap">
            {buildShareSummaryText(generatedLink ?? undefined)}
          </div>

          {/* Action Buttons */}
          <div className="flex flex-wrap items-center gap-3">
            <button
              type="button"
              onClick={handleNativeShare}
              className="px-4 py-2.5 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 text-sm font-semibold flex items-center gap-2"
            >
              <Share2 className="w-4 h-4" />
              {webShareSupported ? 'Native Android / OS Share' : 'Share via App'}
            </button>
            <button
              type="button"
              onClick={handleWhatsAppShare}
              className="px-4 py-2.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-sm font-semibold flex items-center gap-2"
            >
              <MessageCircle className="w-4 h-4" /> Share on WhatsApp
            </button>
            <button
              type="button"
              onClick={handleCopyLink}
              className="px-4 py-2.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-100 text-sm font-medium flex items-center gap-2"
            >
              {copied ? <Check className="w-4 h-4 text-emerald-400" /> : <Copy className="w-4 h-4" />}
              {copied ? 'Copied Link' : 'Copy Secure Link'}
            </button>
            {shareCategory === 'midi' && (
              <button
                type="button"
                onClick={exportAndShareMidi}
                className="px-4 py-2.5 rounded-lg border border-zinc-700 hover:bg-zinc-800 text-zinc-200 text-sm font-medium flex items-center gap-2"
              >
                <Download className="w-4 h-4" /> Share / Download .MID
              </button>
            )}
          </div>

          {shareStatus && <p className="text-xs text-emerald-400">{shareStatus}</p>}
          {shareError && <p className="text-xs text-red-400">{shareError}</p>}

          {/* Recent Audio Ready to Share */}
          <div className="pt-2 border-t border-zinc-800 space-y-2">
            <div className="text-xs font-medium text-zinc-400">Available Mixes & Recordings for Sharing</div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
              {exportedMixes.map((m) => (
                <div key={m.id} className="p-2.5 rounded-lg bg-[#191C24] border border-zinc-800 flex items-center justify-between text-xs">
                  <span className="truncate text-zinc-200 flex items-center gap-1.5">
                    <Music className="w-3.5 h-3.5 text-amber-400 shrink-0" /> {m.name}
                  </span>
                  <span className="font-mono text-zinc-400 shrink-0">{formatBytes(m.sizeBytes)}</span>
                </div>
              ))}
              {recordings.map((r) => (
                <div key={r.id} className="p-2.5 rounded-lg bg-[#191C24] border border-zinc-800 flex items-center justify-between text-xs">
                  <span className="truncate text-zinc-200">{r.name}</span>
                  <span className="font-mono text-zinc-400 shrink-0">{r.durationSec}s</span>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Collaborator Profiles & Contact Invitations */}
        <div className="bg-[#12141A] border border-zinc-800 rounded-xl p-5 space-y-5">
          <h2 className="text-base font-semibold text-zinc-100">Collaborators & Contacts</h2>
          <div className="space-y-2.5">
            {collaborators.map((c) => (
              <div key={c.id} className="p-3 rounded-lg bg-[#191C24] border border-zinc-800 flex items-center justify-between gap-2">
                <div className="min-w-0">
                  <div className="text-sm font-medium text-zinc-100 truncate">{c.name}</div>
                  <div className="text-xs text-zinc-400 truncate">
                    {c.instrument} · {c.role}
                  </div>
                </div>
                <a
                  href={buildWhatsAppUrl(`Hey ${c.name}, let's jump into BEAT LABZ for "${project.title}" (${project.bpm} BPM).`)}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-2.5 py-1.5 rounded bg-zinc-800 hover:bg-emerald-600 text-xs text-zinc-200 hover:text-white shrink-0"
                >
                  Ping
                </a>
              </div>
            ))}
          </div>

          <form onSubmit={submitInvitation} className="space-y-3 pt-3 border-t border-zinc-800">
            <div className="text-xs font-semibold text-zinc-300 flex items-center gap-1.5">
              <UserPlus className="w-3.5 h-3.5 text-amber-400" /> Invite Studio Contact
            </div>
            <input
              type="text"
              placeholder="Musician Name"
              value={inviteName}
              onChange={(e) => setInviteName(e.target.value)}
              required
              className="w-full bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-2 text-xs text-zinc-100"
            />
            <input
              type="email"
              placeholder="musician@example.com"
              value={inviteEmail}
              onChange={(e) => setInviteEmail(e.target.value)}
              required
              className="w-full bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-2 text-xs text-zinc-100"
            />
            <div className="grid grid-cols-2 gap-2">
              <input
                type="text"
                aria-label="Instrument"
                value={inviteInstrument}
                onChange={(e) => setInviteInstrument(e.target.value)}
                className="bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-2 text-xs text-zinc-100"
              />
              <select
                aria-label="Collaborator role"
                value={inviteRole}
                onChange={(e) => setInviteRole(e.target.value as 'editor' | 'commenter' | 'viewer')}
                className="bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-2 text-xs text-zinc-100"
              >
                <option value="editor">Editor</option>
                <option value="commenter">Commenter</option>
                <option value="viewer">Viewer</option>
              </select>
            </div>
            <button
              type="submit"
              className="w-full py-2.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-semibold text-zinc-100"
            >
              Add Contact & Prepare Invite
            </button>
          </form>
        </div>
      </div>
    </div>
  );
};

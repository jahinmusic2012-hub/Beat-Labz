import React, { useEffect, useRef, useState } from 'react';
import { Users, Send, Upload, MessageSquare, Radio, Plus } from 'lucide-react';
import type { ChordChartItem, CollaboratorProfile, RoomComment, SharedAudioAsset, StudioProject } from '../types/studio';
import { audioEngine } from '../audio/audioEngine';
import { parseChordSymbol } from '../utils/musicTheory';
import { formatBytes } from '../utils/shareUtils';

interface CollaborationStudioViewProps {
  project: StudioProject;
  roomId: string;
  onChangeRoomId: (id: string) => void;
  collaborators: CollaboratorProfile[];
  onUpdateRole: (id: string, role: CollaboratorProfile['role']) => void;
}

interface PresencePeer {
  peerId: string;
  name: string;
  role: string;
}

export const CollaborationStudioView: React.FC<CollaborationStudioViewProps> = ({
  project,
  roomId,
  onChangeRoomId,
  collaborators,
  onUpdateRole,
}) => {
  const [wsConnected, setWsConnected] = useState(false);
  const [userName, setUserName] = useState('Studio Producer');
  const [userRole, setUserRole] = useState<'owner' | 'editor' | 'commenter' | 'viewer'>('owner');
  const [sessionStatus, setSessionStatus] = useState<'live' | 'rehearsal' | 'paused'>('live');
  const [presence, setPresence] = useState<PresencePeer[]>([]);
  const [sharedChart, setSharedChart] = useState<ChordChartItem[]>(project.chordChart);
  const [comments, setComments] = useState<RoomComment[]>([]);
  const [sharedAssets, setSharedAssets] = useState<SharedAudioAsset[]>([]);
  const [newComment, setNewComment] = useState('');
  const [newSection, setNewSection] = useState('Bridge');
  const [newChords, setNewChords] = useState('Am7, Fmaj7, C, G');
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [roomInput, setRoomInput] = useState(roomId);

  const wsRef = useRef<WebSocket | null>(null);
  const peerIdRef = useRef(`peer_${Math.random().toString(36).slice(2, 10)}`);

  useEffect(() => {
    const protocol = window.location.protocol === 'https:' ? 'wss:' : 'ws:';
    const wsUrl = `${protocol}//${window.location.host}/ws`;
    const ws = new WebSocket(wsUrl);
    wsRef.current = ws;

    ws.onopen = () => {
      setWsConnected(true);
      ws.send(
        JSON.stringify({
          type: 'session:join',
          roomId,
          payload: {
            peerId: peerIdRef.current,
            name: userName,
            role: userRole,
          },
        })
      );
    };

    ws.onmessage = (ev) => {
      try {
        const msg = JSON.parse(ev.data);
        if (msg.type === 'session:init' && msg.room) {
          setSharedChart(msg.room.chordChart ?? []);
          setComments(msg.room.comments ?? []);
          setSharedAssets(msg.room.sharedAssets ?? []);
          setSessionStatus(msg.room.status ?? 'live');
          setPresence(msg.presence ?? []);
        } else if (msg.type === 'presence:update') {
          setPresence(msg.presence ?? []);
        } else if (msg.type === 'chordchart:update') {
          setSharedChart(msg.chordChart ?? []);
        } else if (msg.type === 'comment:add' && msg.comment) {
          setComments((prev) => (prev.some((c) => c.id === msg.comment.id) ? prev : [...prev, msg.comment]));
        } else if (msg.type === 'audio:shared' && msg.asset) {
          setSharedAssets((prev) => (prev.some((a) => a.id === msg.asset.id) ? prev : [msg.asset, ...prev]));
        } else if (msg.type === 'session:status' && msg.status) {
          setSessionStatus(msg.status);
        }
      } catch {
        // Ignore malformed frames
      }
    };

    ws.onclose = () => setWsConnected(false);

    return () => {
      ws.close();
    };
  }, [roomId, userName, userRole]);

  const sendWs = (type: string, payload: Record<string, unknown>) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(JSON.stringify({ type, roomId, payload }));
    }
  };

  const addSharedChordSection = (e: React.FormEvent) => {
    e.preventDefault();
    const chords = newChords.split(',').map((c) => c.trim()).filter(Boolean);
    if (!chords.length) return;
    const nextChart: ChordChartItem[] = [
      ...sharedChart,
      { id: `sc_${Date.now()}`, section: newSection.trim() || 'Section', chords, lyrics: 'Synced in live room', bars: 4 },
    ];
    setSharedChart(nextChart);
    sendWs('chordchart:update', { chordChart: nextChart });
  };

  const postComment = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newComment.trim()) return;
    const comment: RoomComment = {
      id: `cmt_${Date.now()}_${Math.random().toString(36).slice(2, 6)}`,
      author: userName,
      role: userRole,
      body: newComment.trim(),
      createdAt: new Date().toISOString(),
    };
    setComments((prev) => [...prev, comment]);
    sendWs('comment:add', { comment });
    setNewComment('');
  };

  const handleAudioExchangeUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    setUploadError(null);
    if (file.size > 15 * 1024 * 1024) {
      setUploadError('Audio file must be under 15 MB.');
      return;
    }
    try {
      const arrayBuf = await file.arrayBuffer();
      const bytes = new Uint8Array(arrayBuf);
      let binary = '';
      for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);

      const res = await fetch('/api/audio-objects', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          fileName: file.name,
          mimeType: file.type || 'audio/wav',
          base64Data: btoa(binary),
          projectId: project.id,
          uploader: userName,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || 'Upload failed.');

      const asset: SharedAudioAsset = {
        id: data.id,
        name: data.fileName,
        uploader: userName,
        mimeType: data.mimeType,
        sizeBytes: data.sizeBytes,
        url: data.url,
        createdAt: data.createdAt,
      };
      setSharedAssets((prev) => [asset, ...prev]);
      sendWs('audio:shared', { asset });
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : 'Failed to exchange audio file.');
    }
  };

  return (
    <div className="space-y-6">
      {/* Room Header & WebSocket Connection Status */}
      <div className="bg-[#12141A] border border-zinc-800 rounded-xl p-5 flex flex-col lg:flex-row lg:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold text-zinc-100">Collaboration Studio</h1>
          <p className="text-sm text-zinc-400">
            Real-time WebSocket session sync, shared chord charts, audio file exchange, collaborator roles, and project comments
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-3">
          <div className="flex items-center gap-2 text-xs font-medium px-3 py-2 rounded-lg bg-[#191C24] border border-zinc-800">
            <span className={`w-2 h-2 rounded-full ${wsConnected ? 'bg-emerald-400' : 'bg-red-400'}`} />
            <span>{wsConnected ? `Connected · Room ${roomId}` : 'Reconnecting WebSocket...'}</span>
          </div>

          <select
            aria-label="Session Status"
            value={sessionStatus}
            onChange={(e) => {
              const next = e.target.value as typeof sessionStatus;
              setSessionStatus(next);
              sendWs('session:status', { status: next });
            }}
            className="bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-2 text-xs font-medium text-zinc-100"
          >
            <option value="live">Session: Live Tracking</option>
            <option value="rehearsal">Session: Rehearsal</option>
            <option value="paused">Session: Paused</option>
          </select>
        </div>
      </div>

      {/* Room Switcher + Presence */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-[#12141A] border border-zinc-800 rounded-xl p-5 space-y-4">
          <h2 className="text-base font-semibold text-zinc-100 flex items-center gap-2">
            <Users className="w-4 h-4 text-amber-400" /> Session Presence ({presence.length})
          </h2>

          <div className="grid grid-cols-2 gap-2">
            <input
              type="text"
              aria-label="Your display name"
              value={userName}
              onChange={(e) => setUserName(e.target.value)}
              className="bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-2 text-xs text-zinc-100"
            />
            <select
              aria-label="Your role"
              value={userRole}
              onChange={(e) => setUserRole(e.target.value as typeof userRole)}
              className="bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-2 text-xs text-zinc-100"
            >
              <option value="owner">Owner</option>
              <option value="editor">Editor</option>
              <option value="commenter">Commenter</option>
              <option value="viewer">Viewer</option>
            </select>
          </div>

          <div className="flex gap-2">
            <input
              type="text"
              aria-label="Collaboration Room ID"
              value={roomInput}
              onChange={(e) => setRoomInput(e.target.value)}
              className="flex-1 bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-2 text-xs font-mono text-zinc-100"
            />
            <button
              type="button"
              onClick={() => onChangeRoomId(roomInput.trim() || 'studio-main')}
              className="px-3 py-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-zinc-100"
            >
              Join Room
            </button>
          </div>

          <div className="space-y-2 pt-2 border-t border-zinc-800">
            <div className="text-xs font-medium text-zinc-400">Active Peers in Room</div>
            {presence.map((p) => (
              <div key={p.peerId} className="flex items-center justify-between text-xs bg-[#191C24] border border-zinc-800 rounded-lg px-3 py-2">
                <span className="text-zinc-100 font-medium flex items-center gap-1.5">
                  <Radio className="w-3 h-3 text-emerald-400" /> {p.name}
                </span>
                <span className="text-zinc-400">{p.role}</span>
              </div>
            ))}
          </div>

          <div className="space-y-2 pt-2 border-t border-zinc-800">
            <div className="text-xs font-medium text-zinc-400">Team Roles</div>
            {collaborators.map((c) => (
              <div key={c.id} className="flex items-center justify-between gap-2 text-xs">
                <span className="text-zinc-200 truncate">{c.name}</span>
                <select
                  aria-label={`Role for ${c.name}`}
                  value={c.role}
                  onChange={(e) => onUpdateRole(c.id, e.target.value as CollaboratorProfile['role'])}
                  className="bg-[#191C24] border border-zinc-700 rounded px-2 py-1 text-xs text-zinc-200"
                >
                  <option value="editor">Editor</option>
                  <option value="commenter">Commenter</option>
                  <option value="viewer">Viewer</option>
                </select>
              </div>
            ))}
          </div>
        </div>

        {/* Shared Chord Charts */}
        <div className="bg-[#12141A] border border-zinc-800 rounded-xl p-5 space-y-4">
          <h2 className="text-base font-semibold text-zinc-100">Shared Chord Charts</h2>
          <div className="space-y-2.5 max-h-64 overflow-y-auto pr-1">
            {sharedChart.map((item) => (
              <div key={item.id} className="p-3 rounded-lg bg-[#191C24] border border-zinc-800 space-y-2">
                <div className="text-xs font-semibold text-amber-400">{item.section}</div>
                <div className="flex flex-wrap gap-1.5">
                  {item.chords.map((ch, idx) => (
                    <button
                      key={`${item.id}-${idx}`}
                      type="button"
                      onClick={() => audioEngine.triggerChord(parseChordSymbol(ch, 4).midis, 0.7, 'electric-piano')}
                      className="px-2.5 py-1 rounded bg-[#0D0F14] border border-zinc-700 hover:border-amber-500 font-mono text-xs text-zinc-100"
                    >
                      {ch}
                    </button>
                  ))}
                </div>
              </div>
            ))}
          </div>

          <form onSubmit={addSharedChordSection} className="space-y-2 pt-2 border-t border-zinc-800">
            <input
              type="text"
              placeholder="Section (e.g., Pre-Chorus)"
              value={newSection}
              onChange={(e) => setNewSection(e.target.value)}
              className="w-full bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-2 text-xs text-zinc-100"
            />
            <input
              type="text"
              placeholder="Chords (e.g., Fmaj7, G, Em7, Am7)"
              value={newChords}
              onChange={(e) => setNewChords(e.target.value)}
              className="w-full bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-2 text-xs font-mono text-zinc-100"
            />
            <button
              type="submit"
              className="w-full py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-semibold flex items-center justify-center gap-1"
            >
              <Plus className="w-3.5 h-3.5" /> Sync Chord Section to Room
            </button>
          </form>
        </div>

        {/* Audio File Exchange + Project Comments */}
        <div className="bg-[#12141A] border border-zinc-800 rounded-xl p-5 space-y-5">
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h2 className="text-base font-semibold text-zinc-100">Audio File Exchange</h2>
              <label className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-amber-400 cursor-pointer flex items-center gap-1.5">
                <Upload className="w-3.5 h-3.5" /> Upload Stem
                <input
                  type="file"
                  accept="audio/wav,audio/mpeg,audio/mp3,audio/webm,audio/ogg,.mid,.midi"
                  onChange={handleAudioExchangeUpload}
                  className="hidden"
                />
              </label>
            </div>
            {uploadError && <p className="text-xs text-red-400">{uploadError}</p>}

            <div className="space-y-2 max-h-36 overflow-y-auto">
              {sharedAssets.length === 0 ? (
                <p className="text-xs text-zinc-500">Upload a WAV, MP3, WebM, or MIDI file to share it live with room collaborators.</p>
              ) : (
                sharedAssets.map((a) => (
                  <div key={a.id} className="p-2.5 rounded-lg bg-[#191C24] border border-zinc-800 space-y-1">
                    <div className="flex justify-between text-xs">
                      <span className="text-zinc-100 font-medium truncate">{a.name}</span>
                      <span className="text-zinc-400 font-mono shrink-0">{formatBytes(a.sizeBytes)}</span>
                    </div>
                    <audio controls src={a.url} className="w-full h-8" />
                  </div>
                ))
              )}
            </div>
          </div>

          <div className="space-y-3 pt-3 border-t border-zinc-800">
            <h3 className="text-sm font-semibold text-zinc-100 flex items-center gap-1.5">
              <MessageSquare className="w-4 h-4 text-emerald-400" /> Project Comments
            </h3>
            <div className="space-y-2 max-h-40 overflow-y-auto pr-1">
              {comments.length === 0 ? (
                <p className="text-xs text-zinc-500">No studio comments yet.</p>
              ) : (
                comments.map((c) => (
                  <div key={c.id} className="p-2.5 rounded-lg bg-[#191C24] border border-zinc-800 text-xs space-y-1">
                    <div className="flex justify-between text-zinc-400">
                      <span className="font-semibold text-zinc-200">{c.author} ({c.role})</span>
                      <span>{new Date(c.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</span>
                    </div>
                    <p className="text-zinc-300">{c.body}</p>
                  </div>
                ))
              )}
            </div>
            <form onSubmit={postComment} className="flex gap-2">
              <input
                type="text"
                placeholder="Write feedback or mix note..."
                value={newComment}
                onChange={(e) => setNewComment(e.target.value)}
                className="flex-1 bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-2 text-xs text-zinc-100"
              />
              <button
                type="submit"
                aria-label="Send comment"
                className="px-3 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white"
              >
                <Send className="w-3.5 h-3.5" />
              </button>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

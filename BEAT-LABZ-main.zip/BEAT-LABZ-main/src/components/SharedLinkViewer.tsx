import React, { useEffect, useState } from 'react';
import { Lock, ArrowLeft, MapPin, Music } from 'lucide-react';
import { audioEngine } from '../audio/audioEngine';
import { parseChordSymbol } from '../utils/musicTheory';

interface SharedLinkViewerProps {
  shareToken: string | null;
  locToken: string | null;
  onExitToStudio: () => void;
}

export const SharedLinkViewer: React.FC<SharedLinkViewerProps> = ({
  shareToken,
  locToken,
  onExitToStudio,
}) => {
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [passcodeRequired, setPasscodeRequired] = useState(false);
  const [passcodeInput, setPasscodeInput] = useState('');
  const [shareData, setShareData] = useState<{
    kind: string;
    title: string;
    payload: Record<string, unknown>;
    expiresAt: string;
  } | null>(null);
  const [locData, setLocData] = useState<{
    label: string;
    collaboratorName: string;
    lat: number;
    lng: number;
    accuracy?: number;
    expiresAt: string;
  } | null>(null);

  const loadResource = async (code?: string) => {
    setLoading(true);
    setError(null);
    try {
      if (shareToken) {
        const qs = code ? `?code=${encodeURIComponent(code)}` : '';
        const res = await fetch(`/api/shares/${encodeURIComponent(shareToken)}${qs}`);
        const data = await res.json();
        if (!res.ok) {
          if (data.passcodeRequired) setPasscodeRequired(true);
          throw new Error(data.error || 'Unable to load shared item.');
        }
        setPasscodeRequired(false);
        setShareData(data);
      } else if (locToken) {
        const res = await fetch(`/api/location-shares/${encodeURIComponent(locToken)}`);
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || 'Location share expired or stopped.');
        setLocData(data);
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to open link.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void loadResource();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [shareToken, locToken]);

  return (
    <div className="min-h-screen bg-[#0A0B0E] text-zinc-100 p-6 flex items-center justify-center">
      <div className="max-w-2xl w-full bg-[#12141A] border border-zinc-800 rounded-2xl p-6 space-y-5">
        <div className="flex items-center justify-between">
          <span className="text-lg font-display font-bold tracking-tight text-amber-400">BEAT LABZ</span>
          <button
            type="button"
            onClick={onExitToStudio}
            className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-xs font-medium text-zinc-200 flex items-center gap-1.5"
          >
            <ArrowLeft className="w-3.5 h-3.5" /> Open Studio
          </button>
        </div>

        {loading && <p className="text-sm text-zinc-400">Loading shared studio resource...</p>}

        {passcodeRequired && (
          <form
            onSubmit={(e) => {
              e.preventDefault();
              void loadResource(passcodeInput);
            }}
            className="space-y-3 bg-[#191C24] border border-zinc-800 rounded-xl p-4"
          >
            <div className="flex items-center gap-2 text-sm font-semibold text-amber-400">
              <Lock className="w-4 h-4" /> Private Project Share Protected
            </div>
            <input
              type="password"
              placeholder="Enter share passcode"
              value={passcodeInput}
              onChange={(e) => setPasscodeInput(e.target.value)}
              className="w-full bg-[#0D0F14] border border-zinc-700 rounded-lg px-3 py-2 text-sm text-zinc-100"
            />
            <button
              type="submit"
              className="px-4 py-2 rounded-lg bg-amber-500 hover:bg-amber-400 text-zinc-950 text-xs font-semibold"
            >
              Unlock Share
            </button>
          </form>
        )}

        {error && !passcodeRequired && (
          <div className="p-4 rounded-xl bg-red-500/10 border border-red-500/30 text-sm text-red-300">{error}</div>
        )}

        {shareData && (
          <div className="space-y-4">
            <div>
              <div className="text-xs text-zinc-400 uppercase tracking-wider">{shareData.kind}</div>
              <h1 className="text-2xl font-bold text-zinc-100 mt-1">{shareData.title}</h1>
            </div>

            {typeof shareData.payload.latestMixUrl === 'string' && shareData.payload.latestMixUrl && (
              <div className="p-4 rounded-xl bg-[#191C24] border border-zinc-800 space-y-2">
                <div className="text-xs font-semibold text-amber-400 flex items-center gap-1.5">
                  <Music className="w-3.5 h-3.5" /> Shared Mix Audio
                </div>
                <audio controls src={shareData.payload.latestMixUrl} className="w-full" />
              </div>
            )}

            {Array.isArray(shareData.payload.chordChart) && (
              <div className="space-y-2">
                <div className="text-xs font-semibold text-zinc-400">Chord Chart</div>
                {(shareData.payload.chordChart as Array<{ id: string; section: string; chords: string[] }>).map((sec) => (
                  <div key={sec.id} className="p-3 rounded-lg bg-[#191C24] border border-zinc-800 flex flex-wrap items-center justify-between gap-2">
                    <span className="text-xs font-semibold text-amber-400">{sec.section}</span>
                    <div className="flex flex-wrap gap-1.5">
                      {sec.chords.map((c, idx) => (
                        <button
                          key={idx}
                          type="button"
                          onClick={() => audioEngine.triggerChord(parseChordSymbol(c, 4).midis, 0.7, 'electric-piano')}
                          className="px-2.5 py-1 rounded bg-[#0D0F14] border border-zinc-700 font-mono text-xs text-zinc-100"
                        >
                          {c}
                        </button>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>
        )}

        {locData && (
          <div className="space-y-4">
            <div className="flex items-center gap-2 text-amber-400 font-semibold">
              <MapPin className="w-5 h-5" />
              <span>{locData.label}</span>
            </div>
            <div className="p-4 rounded-xl bg-[#191C24] border border-zinc-800 space-y-1 text-sm font-mono tabular-nums">
              <div>Shared for: {locData.collaboratorName}</div>
              <div>Coordinates: {locData.lat.toFixed(6)}, {locData.lng.toFixed(6)}</div>
              <div className="text-xs text-zinc-400">
                Expires at {new Date(locData.expiresAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
              </div>
            </div>
            <a
              href={`https://maps.google.com/?q=${locData.lat},${locData.lng}`}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-block px-4 py-2.5 rounded-lg bg-amber-500 text-zinc-950 text-xs font-semibold"
            >
              Open in Google Maps
            </a>
          </div>
        )}
      </div>
    </div>
  );
};

import React, { useState } from 'react';
import { Sparkles, Send, Music, Sliders } from 'lucide-react';
import type { StudioProject } from '../types/studio';
import { audioEngine } from '../audio/audioEngine';
import { parseChordSymbol } from '../utils/musicTheory';

interface AiAssistantViewProps {
  project: StudioProject;
  onApplyBpm: (bpm: number) => void;
}

interface AiAssistantResult {
  summary: string;
  detailedAdvice: string;
  recommendedChords: string[];
  suggestedBpm?: number;
  eqAndMixTips: string[];
  voicingNotes?: string;
}

const ASSISTANT_MODES = [
  { id: 'chords', label: 'Chord Recommendations', sample: 'Suggest an uplifting bridge chord progression in C Major that lifts smoothly into the final chorus.' },
  { id: 'theory', label: 'Music Theory', sample: 'Explain why modal interchange with iv or bVI works so well in modern arrangements.' },
  { id: 'arrangement', label: 'Song Arrangement', sample: 'Structure a dynamic 4-minute arrangement from intimate intro to full-band climax.' },
  { id: 'worship', label: 'Worship Arrangement', sample: 'How should I layer shimmer pads, electric piano, and acoustic guitar for a modern worship set?' },
  { id: 'mixing', label: 'Mixing & EQ Guidance', sample: 'Give me exact EQ cuts and compression settings so kick, sub bass, and vocals do not clash.' },
  { id: 'vocals', label: 'Vocal Recording', sample: 'Share vocal mic placement, gain staging, and double-tracking tips for clear lead vocals.' },
  { id: 'guitar', label: 'Guitar Chords', sample: 'Recommend open-voicing guitar shapes and capo options for playing in C Major / A Minor.' },
  { id: 'piano', label: 'Piano Voicings', sample: 'Show lush 9th and sus2 piano voicings for left-hand/right-hand separation.' },
];

export const AiAssistantView: React.FC<AiAssistantViewProps> = ({ project, onApplyBpm }) => {
  const [mode, setMode] = useState('chords');
  const [prompt, setPrompt] = useState(ASSISTANT_MODES[0].sample);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [result, setResult] = useState<AiAssistantResult | null>(null);

  const askAssistant = async (e?: React.FormEvent) => {
    e?.preventDefault();
    if (!prompt.trim()) return;
    setLoading(true);
    setError(null);
    try {
      const res = await fetch('/api/ai/assist', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: prompt.trim(),
          category: mode,
          context: {
            title: project.title,
            musicalKey: project.musicalKey,
            bpm: project.bpm,
            timeSignature: project.timeSignature,
          },
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        throw new Error(data.error || 'AI Assistant request failed.');
      }
      setResult(data.result as AiAssistantResult);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Unable to reach BEAT LABZ AI backend.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-[#12141A] border border-zinc-800 rounded-xl p-5">
        <h1 className="text-xl font-bold text-zinc-100">BEAT LABZ AI Assistant</h1>
        <p className="text-sm text-zinc-400">
          Server-side Gemini producer intelligence for chord progressions, theory, arrangement, worship layering, vocal coaching, mixing, and EQ
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="bg-[#12141A] border border-zinc-800 rounded-xl p-5 space-y-4">
          <h2 className="text-base font-semibold text-zinc-100">Studio Focus Mode</h2>
          <div className="grid grid-cols-2 gap-2">
            {ASSISTANT_MODES.map((m) => (
              <button
                key={m.id}
                type="button"
                onClick={() => {
                  setMode(m.id);
                  setPrompt(m.sample);
                }}
                className={`px-3 py-2 rounded-lg text-xs font-medium text-left border transition-colors ${
                  mode === m.id
                    ? 'bg-amber-500 text-zinc-950 border-amber-400 font-semibold'
                    : 'bg-[#191C24] border-zinc-800 text-zinc-300 hover:border-zinc-600'
                }`}
              >
                {m.label}
              </button>
            ))}
          </div>

          <form onSubmit={askAssistant} className="space-y-3 pt-2 border-t border-zinc-800">
            <label className="block space-y-1">
              <span className="text-xs text-zinc-400">Ask about "{project.title}" ({project.musicalKey} · {project.bpm} BPM)</span>
              <textarea
                rows={4}
                value={prompt}
                onChange={(e) => setPrompt(e.target.value)}
                className="w-full bg-[#191C24] border border-zinc-700 rounded-lg px-3 py-2 text-sm text-zinc-100 focus:outline-none focus:ring-2 focus:ring-amber-500"
              />
            </label>
            <button
              type="submit"
              disabled={loading}
              className="w-full py-2.5 px-4 rounded-lg bg-amber-500 hover:bg-amber-400 disabled:opacity-50 text-zinc-950 text-sm font-semibold flex items-center justify-center gap-2"
            >
              <Send className="w-4 h-4" />
              {loading ? 'Analyzing Session...' : 'Ask BEAT LABZ AI'}
            </button>
          </form>

          {error && (
            <div className="p-3 rounded-lg bg-red-500/10 border border-red-500/30 text-xs text-red-300">
              {error}
            </div>
          )}
        </div>

        <div className="lg:col-span-2 bg-[#12141A] border border-zinc-800 rounded-xl p-6">
          {!result && !loading && (
            <div className="h-full min-h-[300px] flex flex-col items-center justify-center text-center space-y-3 text-zinc-400">
              <Sparkles className="w-8 h-8 text-amber-400" />
              <div className="text-sm font-medium text-zinc-200">Ready to assist with your active DAW session</div>
              <p className="text-xs max-w-md text-zinc-400">
                Select a topic on the left or write any question about chords, tempo, instruments, EQ, vocals, guitar, or piano voicings.
              </p>
            </div>
          )}

          {loading && (
            <div className="space-y-3 animate-pulse">
              <div className="h-6 bg-zinc-800 rounded w-2/3" />
              <div className="h-24 bg-zinc-800 rounded w-full" />
              <div className="h-12 bg-zinc-800 rounded w-1/2" />
            </div>
          )}

          {result && !loading && (
            <div className="space-y-5">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <h3 className="text-lg font-bold text-zinc-100">{result.summary}</h3>
                {typeof result.suggestedBpm === 'number' && result.suggestedBpm >= 40 && result.suggestedBpm <= 240 && (
                  <button
                    type="button"
                    onClick={() => onApplyBpm(Math.round(result.suggestedBpm!))}
                    className="px-3 py-1.5 rounded-lg bg-amber-500/15 border border-amber-500/40 text-amber-300 text-xs font-mono font-semibold hover:bg-amber-500 hover:text-zinc-950 transition-colors"
                  >
                    Apply {Math.round(result.suggestedBpm)} BPM to DAW
                  </button>
                )}
              </div>

              <div className="text-sm text-zinc-300 leading-relaxed whitespace-pre-line">
                {result.detailedAdvice}
              </div>

              {result.recommendedChords?.length > 0 && (
                <div className="space-y-2">
                  <div className="text-xs font-semibold text-zinc-400 flex items-center gap-1.5">
                    <Music className="w-3.5 h-3.5 text-amber-400" /> Playable Chord Suggestions (Click to Audition)
                  </div>
                  <div className="flex flex-wrap gap-2">
                    {result.recommendedChords.map((chord, idx) => (
                      <button
                        key={`${chord}-${idx}`}
                        type="button"
                        onClick={() => {
                          const parsed = parseChordSymbol(chord, 4);
                          audioEngine.triggerChord(parsed.midis, 0.85, 'electric-piano');
                        }}
                        className="px-3.5 py-2 rounded-lg bg-[#191C24] border border-zinc-700 hover:border-amber-500 font-mono text-sm font-semibold text-zinc-100"
                      >
                        {chord}
                      </button>
                    ))}
                  </div>
                </div>
              )}

              {result.eqAndMixTips?.length > 0 && (
                <div className="space-y-2 pt-2 border-t border-zinc-800">
                  <div className="text-xs font-semibold text-zinc-400 flex items-center gap-1.5">
                    <Sliders className="w-3.5 h-3.5 text-emerald-400" /> Mixing, EQ & Production Notes
                  </div>
                  <ul className="space-y-1.5 text-xs text-zinc-300 list-disc pl-5">
                    {result.eqAndMixTips.map((tip, idx) => (
                      <li key={idx}>{tip}</li>
                    ))}
                  </ul>
                </div>
              )}

              {result.voicingNotes && (
                <div className="p-3.5 rounded-lg bg-[#191C24] border border-zinc-800 text-xs text-zinc-300">
                  <span className="font-semibold text-amber-400">Voicing & Instrument Notes: </span>
                  {result.voicingNotes}
                </div>
              )}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

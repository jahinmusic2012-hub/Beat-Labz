import test from 'node:test';
import assert from 'node:assert/strict';
import {
  encodeWavBuffer,
  encodeMp3Buffer,
  analyzeStereoBuffer,
  applyMasteringDSP,
  computeParametricEqResponseDb,
} from './audioExport';
import type { MasteringSettings } from '../types/studio';

function makeSineStereo(freq: number, amp: number, sampleRate: number, seconds: number) {
  const len = Math.floor(sampleRate * seconds);
  const left = new Float32Array(len);
  const right = new Float32Array(len);
  for (let i = 0; i < len; i++) {
    const val = amp * Math.sin((2 * Math.PI * freq * i) / sampleRate);
    left[i] = val;
    right[i] = val;
  }
  return { left, right };
}

test('encodeWavBuffer outputs valid RIFF/WAVE header and payload size', () => {
  const { left, right } = makeSineStereo(440, 0.5, 44100, 0.1);
  const wav = encodeWavBuffer([left, right], 44100);
  assert.equal(String.fromCharCode(...wav.slice(0, 4)), 'RIFF');
  assert.equal(String.fromCharCode(...wav.slice(8, 12)), 'WAVE');
  assert.equal(wav.length, 44 + left.length * 2 * 2);
});

test('encodeMp3Buffer encodes real MP3 MPEG frames via lamejs', () => {
  const { left, right } = makeSineStereo(440, 0.5, 44100, 0.25);
  const mp3 = encodeMp3Buffer([left, right], 44100, 192);
  assert.ok(mp3.length > 500, 'MP3 output should contain encoded frames');
  assert.equal(mp3[0], 0xff);
  assert.equal(mp3[1] & 0xe0, 0xe0);
});

test('analyzeStereoBuffer detects correlation, LUFS, true peak, and clipping', () => {
  const { left, right } = makeSineStereo(440, 1.0, 44100, 0.1);
  const metrics = analyzeStereoBuffer(left, right, 44100);
  assert.equal(metrics.correlation, 1);
  assert.ok(metrics.truePeakDb > -0.1);
  assert.ok(metrics.clippedSamples > 0);
  assert.ok(metrics.lufs > -10 && metrics.lufs < 0);
});

test('applyMasteringDSP limits hot signal below ceiling', () => {
  const { left, right } = makeSineStereo(220, 1.2, 44100, 0.1);
  const settings: MasteringSettings = {
    presetName: 'Test Limit',
    lowGainDb: 0,
    lowFreqHz: 90,
    midGainDb: 0,
    midFreqHz: 1200,
    midQ: 1,
    highGainDb: 0,
    highFreqHz: 10000,
    lowBandThresholdDb: -16,
    midBandThresholdDb: -16,
    highBandThresholdDb: -18,
    compRatio: 3,
    stereoWidth: 1,
    limiterCeilingDb: -1.0,
    makeupGainDb: 0,
  };
  const out = applyMasteringDSP(left, right, 44100, settings);
  const metrics = analyzeStereoBuffer(out.left, out.right, 44100);
  assert.equal(metrics.clippedSamples, 0);
  assert.ok(metrics.truePeakDb <= -0.95);
});

test('computeParametricEqResponseDb reflects boost and cut curves accurately', () => {
  const settings: MasteringSettings = {
    presetName: 'EQ Probe',
    lowGainDb: 4,
    lowFreqHz: 90,
    midGainDb: -3,
    midFreqHz: 1000,
    midQ: 1.2,
    highGainDb: 3,
    highFreqHz: 10000,
    lowBandThresholdDb: -16,
    midBandThresholdDb: -18,
    highBandThresholdDb: -20,
    compRatio: 2.5,
    stereoWidth: 1,
    limiterCeilingDb: -0.5,
    makeupGainDb: 0,
  };
  const curve = computeParametricEqResponseDb(settings, 44100, [40, 1000, 14000]);
  assert.ok(curve[0] > 3.0, '40Hz low shelf boost should exceed +3dB');
  assert.ok(curve[1] < -2.0, '1kHz mid cut should dip below -2dB');
  assert.ok(curve[2] > 2.0, '14kHz high air boost should exceed +2dB');
});

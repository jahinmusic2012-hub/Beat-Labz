import test from 'node:test';
import assert from 'node:assert/strict';
import {
  buildWhatsAppUrl,
  formatLocationShareMessage,
  isLocationShareActive,
  formatBytes,
} from './shareUtils';

test('buildWhatsAppUrl encodes text cleanly', () => {
  const url = buildWhatsAppUrl('Listen to Beat Labz Mix');
  assert.equal(url, 'https://wa.me/?text=Listen%20to%20Beat%20Labz%20Mix');
});

test('formatLocationShareMessage formats coordinates and Google Maps link', () => {
  const msg = formatLocationShareMessage({ lat: 37.774929, lng: -122.419416, accuracy: 12 }, 'Rehearsal Studio');
  assert.match(msg, /Rehearsal Studio/);
  assert.match(msg, /37\.774929, -122\.419416/);
  assert.match(msg, /https:\/\/maps\.google\.com\/\?q=37\.774929,-122\.419416/);
});

test('isLocationShareActive enforces stop and expiry strictly', () => {
  assert.equal(isLocationShareActive(2000, false, 1000), true);
  assert.equal(isLocationShareActive(2000, true, 1000), false);
  assert.equal(isLocationShareActive(1000, false, 2000), false);
  assert.equal(isLocationShareActive(null, false, 1000), false);
});

test('formatBytes formats B, KB, and MB cleanly', () => {
  assert.equal(formatBytes(512), '512 B');
  assert.equal(formatBytes(2048), '2.0 KB');
  assert.equal(formatBytes(5 * 1024 * 1024), '5.00 MB');
});

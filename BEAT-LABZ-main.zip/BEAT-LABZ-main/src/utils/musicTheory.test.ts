import test from 'node:test';
import assert from 'node:assert/strict';
import {
  midiToFreq,
  midiToNoteName,
  noteNameToMidi,
  getScaleNotes,
  getChordNotes,
  transposeChordSymbol,
  getGuitarVoicing,
  buildMidiFileBytes,
  generateEuclideanSteps,
  shiftStepArray,
} from './musicTheory';
import type { SequencerTrack } from '../types/studio';

test('MIDI pitch and note name conversions match A4 = 440Hz', () => {
  assert.equal(Math.round(midiToFreq(69)), 440);
  assert.equal(noteNameToMidi('A4'), 69);
  assert.equal(midiToNoteName(60), 'C4');
});

test('getScaleNotes and getChordNotes return accurate intervals', () => {
  const cMaj = getScaleNotes('C', 'major', 4);
  assert.deepEqual(cMaj.names, ['C', 'D', 'E', 'F', 'G', 'A', 'B']);

  const g7 = getChordNotes('G', '7', 3);
  assert.equal(g7.symbol, 'G7');
  assert.deepEqual(g7.names, ['G', 'B', 'D', 'F']);
});

test('transposeChordSymbol handles slash chords and accidentals', () => {
  assert.equal(transposeChordSymbol('C/G', 2), 'D/A');
  assert.equal(transposeChordSymbol('Am7', 5), 'Dm7');
});

test('getGuitarVoicing produces 6-string fretboard voicing with root', () => {
  const cVoicing = getGuitarVoicing('C');
  assert.equal(cVoicing.frets.length, 6);
  assert.ok(cVoicing.midis.length >= 4);
});

test('buildMidiFileBytes generates valid SMF MThd and MTrk headers', () => {
  const tracks: SequencerTrack[] = [
    {
      id: 't1',
      name: 'Drums',
      kind: 'drums',
      color: '#F59E0B',
      volume: 0.9,
      pan: 0,
      muted: false,
      solo: false,
      eqLow: 0,
      eqHigh: 0,
      reverbSend: 0.1,
      steps: [true, false, false, false, true, false, false, false, false, false, false, false, false, false, false, false],
      notes: [0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0],
      instrumentPreset: 'kit-studio',
    },
  ];
  const bytes = buildMidiFileBytes(tracks, 120);
  const headerStr = String.fromCharCode(...bytes.slice(0, 4));
  assert.equal(headerStr, 'MThd');
  assert.ok(bytes.length > 22);
});

test('generateEuclideanSteps distributes pulses evenly and starts on downbeat', () => {
  const fourOnFloor = generateEuclideanSteps(4, 16);
  assert.equal(fourOnFloor.filter(Boolean).length, 4);
  assert.equal(fourOnFloor[0], true);
  assert.equal(fourOnFloor[4], true);
  assert.equal(fourOnFloor[8], true);
  assert.equal(fourOnFloor[12], true);

  const tresillo = generateEuclideanSteps(5, 16);
  assert.equal(tresillo.filter(Boolean).length, 5);
  assert.equal(tresillo[0], true);
});

test('shiftStepArray rotates pattern steps cleanly left and right', () => {
  const base = [1, 2, 3, 4];
  assert.deepEqual(shiftStepArray(base, 1), [4, 1, 2, 3]);
  assert.deepEqual(shiftStepArray(base, -1), [2, 3, 4, 1]);
});

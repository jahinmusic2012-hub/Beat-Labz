export type WorkspaceTab =
  | 'studio'
  | 'mastering'
  | 'live'
  | 'collaborate'
  | 'connect'
  | 'location'
  | 'ai'
  | 'cloud'
  | 'learn';

export type TrackKind = 'drums' | 'synth' | 'bass' | 'keys' | 'audio';

export interface SequencerTrack {
  id: string;
  name: string;
  kind: TrackKind;
  color: string;
  volume: number; // 0..1.2
  pan: number; // -1..1
  muted: boolean;
  solo: boolean;
  eqLow: number; // -12..12 dB
  eqHigh: number; // -12..12 dB
  reverbSend: number; // 0..1
  steps: boolean[]; // 16-step pattern
  notes: number[]; // MIDI note per step (for melodic tracks) or drum voice index
  instrumentPreset: string;
}

export interface RecordedTake {
  id: string;
  name: string;
  durationSec: number;
  sampleRate: number;
  createdAt: string;
  mimeType: string;
  sizeBytes: number;
  objectUrl?: string;
  localBlobUrl?: string;
  waveformPeaks: number[];
}

export interface ChordChartItem {
  id: string;
  section: string;
  chords: string[];
  lyrics: string;
  bars: number;
}

export interface SongbookEntry {
  title: string;
  artist: string;
  capo: number;
  notes: string;
  worshipTheme?: string;
}

export interface MasteringSettings {
  presetName: string;
  lowGainDb: number; // 80 Hz shelf/bell
  lowFreqHz: number;
  midGainDb: number; // 1.2 kHz bell
  midFreqHz: number;
  midQ: number;
  highGainDb: number; // 10 kHz shelf
  highFreqHz: number;
  lowBandThresholdDb: number;
  midBandThresholdDb: number;
  highBandThresholdDb: number;
  compRatio: number;
  stereoWidth: number; // 0.5..1.6
  limiterCeilingDb: number; // -3.0..-0.1
  makeupGainDb: number; // 0..12
}

export interface MasteringMetrics {
  lufs: number;
  rmsDb: number;
  truePeakDb: number;
  clippedSamples: number;
  correlation: number;
  leftRmsDb: number;
  rightRmsDb: number;
}

export interface SetlistItem {
  id: string;
  title: string;
  bpm: number;
  musicalKey: string;
  timeSignature: string;
  chords: string[];
  notes: string;
}

export interface MidiFootMapping {
  id: string;
  action: 'next_song' | 'prev_song' | 'toggle_play' | 'toggle_metronome' | 'emergency_mute';
  label: string;
  midiChannel: number;
  ccNumber: number;
}

export interface CollaboratorProfile {
  id: string;
  name: string;
  email: string;
  role: 'owner' | 'editor' | 'commenter' | 'viewer';
  instrument: string;
  online?: boolean;
}

export interface RoomComment {
  id: string;
  author: string;
  role: string;
  body: string;
  createdAt: string;
}

export interface SharedAudioAsset {
  id: string;
  name: string;
  uploader: string;
  mimeType: string;
  sizeBytes: number;
  url: string;
  createdAt: string;
}

export interface PracticeSessionLog {
  id: string;
  module: 'keyboard' | 'guitar' | 'ear_training' | 'rhythm' | 'theory';
  topic: string;
  scorePct: number;
  durationSec: number;
  completedAt: string;
}

export interface StudioProject {
  id: string;
  title: string;
  bpm: number;
  swing?: number; // 0..60 %
  timeSignature: string;
  musicalKey: string;
  isPrivate: boolean;
  shareToken?: string;
  tracks: SequencerTrack[];
  chordChart: ChordChartItem[];
  songbook: SongbookEntry;
  mastering: MasteringSettings;
  updatedAt: string;
}
